# 🔑 Telegram API Credentials Setup

## ⚠️ ВАЖНО: Приложение требует настоящие API credentials

Это приложение использует **только реальную интеграцию с Telegram API** через gramjs. Демо-режим удален по запросу.

## 📋 Пошаговая инструкция:

### 1. Получите API credentials

1. Перейдите на https://my.telegram.org
2. Войдите с вашим номером телефона 
3. Нажмите "API development tools"
4. Создайте новое приложение:
   - **App title**: "Telegram Clone App"
   - **Short name**: "tg-clone"
   - **Platform**: "Web"
   - **Description**: "Telegram clone application"
5. Скопируйте **API ID** и **API Hash**

### 2. Установите credentials в проект

Используйте DevServerControl для установки переменных окружения:

```bash
TELEGRAM_API_ID=ваш_api_id
TELEGRAM_API_HASH=ваш_api_hash
```

### 3. Перезапустите сервер

После установки credentials обязательно перезапустите сервер.

## 🚀 После настройки

✅ Приложение будет отправлять **реальные SMS** коды
✅ Подключение к **настоящим чатам** пользователя  
✅ Отправка **реальных сообщений**
✅ Полная функциональность Telegram API

## ❌ Без валидных credentials

- Приложение не будет работать
- Получите ошибку "API_ID and API_HASH required"
- Никаких fallback'ов или демо-режимов

## 🔐 Безопасность

- Никогда не публикуйте API Hash в open source
- Используйте environment variables  
- API Hash - это секретный ключ доступа к вашему аккаунту
