# Telegram API Setup Guide

This application uses **real Telegram API integration only** via gramjs library.

## ⚠️ IMPORTANT: API Credentials Required

The app requires valid Telegram API credentials. Without them, the app will not work.

## Getting API Credentials

1. Go to [https://my.telegram.org/apps](https://my.telegram.org/apps)
2. Log in with your Telegram account
3. Create a new application:
   - **App title**: Your app name (e.g., "My Telegram Clone")
   - **Short name**: A short identifier (e.g., "mytgclone")
   - **Platform**: Web
   - **Description**: Optional description
4. Copy the **API ID** and **API Hash**

## Configuration

### Required Environment Variables

You MUST set these environment variables with YOUR OWN credentials:

```env
TELEGRAM_API_ID=YOUR_API_ID
TELEGRAM_API_HASH=YOUR_API_HASH
```

Use the DevServerControl tool to set these:
1. `TELEGRAM_API_ID` - Your API ID from my.telegram.org
2. `TELEGRAM_API_HASH` - Your API Hash from my.telegram.org

## Security Notes

⚠️ **Important**: 
- Never commit real API credentials to version control
- The current values in `.env` are examples/test values
- For production, use environment variables or secure secret management

## Usage

Once configured:

1. **Authentication**: Enter your phone number to receive SMS code
2. **2FA Support**: If enabled, you'll be prompted for your 2FA password
3. **Real Chats**: View your actual Telegram conversations
4. **Send Messages**: Send real messages to your contacts
5. **Live Updates**: See real-time message updates

## Features Implemented

✅ **Authentication Flow**
- Phone number verification
- SMS code verification  
- 2FA password support

✅ **Chat Management**
- Load real chat list
- Display unread counts
- Show online status
- Group chat support

✅ **Messaging**
- Send real messages
- Load message history
- Optimistic UI updates
- Delivery confirmation

✅ **Error Handling**
- Connection errors
- Authentication failures
- API rate limiting
- Offline support

## Development Notes

The app connects directly to Telegram API servers. Ensure you have valid API credentials and proper error handling for connection issues.

## Troubleshooting

**"Failed to connect to Telegram"**
- Check your internet connection
- Verify API credentials are correct
- Ensure API ID is a number, not a string

**"Invalid phone number"**
- Use international format: +1234567890
- Include country code

**"Invalid code"**
- Enter the 5-digit code from SMS
- Code expires after a few minutes

**"Session errors"**
- Clear browser storage and re-authenticate
- Session data is stored in browser local storage
