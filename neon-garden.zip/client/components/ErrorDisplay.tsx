import React from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Clock } from 'lucide-react';

interface ErrorDisplayProps {
  error: string;
}

export function ErrorDisplay({ error }: ErrorDisplayProps) {
  const isRateLimit = error.includes('Too many requests') || error.includes('Please wait');
  
  return (
    <Alert variant={isRateLimit ? "default" : "destructive"}>
      {isRateLimit ? (
        <Clock className="h-4 w-4" />
      ) : (
        <AlertCircle className="h-4 w-4" />
      )}
      <AlertDescription>
        {isRateLimit ? (
          <div className="space-y-2">
            <p className="font-medium text-orange-600">Rate Limited</p>
            <p className="text-sm">{error}</p>
            <p className="text-xs text-muted-foreground">
              This is a Telegram API limitation. The wait time is enforced by Telegram servers.
            </p>
          </div>
        ) : (
          error
        )}
      </AlertDescription>
    </Alert>
  );
}
