import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { Download, Play, Pause, Music } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface AudioMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function AudioMessage({ message, onDownload }: AudioMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const audio = message.media?.[0];
  if (!audio) {
    return (
      <div className="text-sm text-muted-foreground">
        🎵 Audio (unavailable)
      </div>
    );
  }

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload(message.id, 0);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="space-y-2">
      {/* Audio player */}
      <div className="flex items-center gap-3 p-3 bg-muted rounded-lg max-w-sm">
        {/* Play/Pause button */}
        <Button
          size="sm"
          variant="secondary"
          className="h-10 w-10 rounded-full flex-shrink-0"
          onClick={handlePlayPause}
        >
          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 ml-0.5" />}
        </Button>

        {/* Audio info and progress */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2 min-w-0">
              <Music className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              <div className="min-w-0">
                <div className="text-sm font-medium truncate">
                  {audio.title || audio.filename || 'Audio'}
                </div>
                {audio.performer && (
                  <div className="text-xs text-muted-foreground truncate">
                    {audio.performer}
                  </div>
                )}
              </div>
            </div>
            <Button
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0 flex-shrink-0"
              onClick={handleDownload}
            >
              <Download className="h-3 w-3" />
            </Button>
          </div>

          {/* Progress bar */}
          <div className="space-y-1">
            <Progress value={progress} className="h-1" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(audio.duration || 0)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* File info */}
      <div className="text-xs text-muted-foreground">
        {formatFileSize(audio.size)} • {audio.mimeType}
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}

      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
        className="hidden"
      />
    </div>
  );
}

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
