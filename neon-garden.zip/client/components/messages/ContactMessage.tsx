import React from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { User, Phone, MessageSquare } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface ContactMessageProps {
  message: Message;
}

export function ContactMessage({ message }: ContactMessageProps) {
  const contact = message.media?.[0];
  if (!contact) {
    return (
      <div className="text-sm text-muted-foreground">
        👤 Contact (unavailable)
      </div>
    );
  }

  const fullName = [contact.firstName, contact.lastName].filter(Boolean).join(' ');
  const initials = [contact.firstName, contact.lastName]
    .filter(Boolean)
    .map(name => name.charAt(0))
    .join('')
    .toUpperCase();

  const handleCall = () => {
    if (contact.phoneNumber) {
      window.open(`tel:${contact.phoneNumber}`, '_self');
    }
  };

  const handleMessage = () => {
    if (contact.phoneNumber) {
      window.open(`sms:${contact.phoneNumber}`, '_self');
    }
  };

  return (
    <div className="space-y-2">
      {/* Contact container */}
      <div className="flex items-center gap-3 p-3 bg-muted rounded-lg max-w-sm">
        {/* Avatar */}
        <Avatar className="h-12 w-12">
          <AvatarFallback className="bg-primary/20 text-primary">
            {initials || <User className="h-6 w-6" />}
          </AvatarFallback>
        </Avatar>

        {/* Contact info */}
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium truncate">
            {fullName || 'Unknown Contact'}
          </div>
          {contact.phoneNumber && (
            <div className="text-xs text-muted-foreground">
              {contact.phoneNumber}
            </div>
          )}
          {contact.userId && (
            <div className="text-xs text-muted-foreground">
              Telegram user
            </div>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex gap-1">
          {contact.phoneNumber && (
            <>
              <Button
                size="sm"
                variant="outline"
                className="h-8 w-8 p-0"
                onClick={handleCall}
                title="Call"
              >
                <Phone className="h-3 w-3" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="h-8 w-8 p-0"
                onClick={handleMessage}
                title="Message"
              >
                <MessageSquare className="h-3 w-3" />
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}
