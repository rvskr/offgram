import React from 'react';
import { Message } from '../../services/database';
import { Trash2 } from 'lucide-react';
import { formatTime } from '../../lib/utils';

interface DeletedMessageProps {
  message: Message;
}

export function DeletedMessage({ message }: DeletedMessageProps) {
  return (
    <div className="flex items-center gap-2 text-muted-foreground italic">
      <Trash2 className="h-4 w-4 flex-shrink-0" />
      <div className="flex-1">
        <div className="text-sm">
          This message was deleted
        </div>
        {message.deletedAt && (
          <div className="text-xs">
            Deleted on {formatTime(message.deletedAt)}
          </div>
        )}
      </div>
    </div>
  );
}
