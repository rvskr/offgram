import React from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { Download, FileText, File, Image, Video, Music, Archive } from 'lucide-react';

interface DocumentMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function DocumentMessage({ message, onDownload }: DocumentMessageProps) {
  const document = message.media?.[0];
  if (!document) {
    return (
      <div className="text-sm text-muted-foreground">
        📎 Document (unavailable)
      </div>
    );
  }

  const handleDownload = () => {
    if (onDownload) {
      onDownload(message.id, 0);
    }
  };

  const getFileIcon = (mimeType?: string, filename?: string) => {
    if (!mimeType && !filename) return <File className="h-8 w-8" />;

    const type = mimeType || '';
    const name = filename || '';

    if (type.startsWith('image/')) return <Image className="h-8 w-8" />;
    if (type.startsWith('video/')) return <Video className="h-8 w-8" />;
    if (type.startsWith('audio/')) return <Music className="h-8 w-8" />;
    if (type.includes('pdf') || name.endsWith('.pdf')) return <FileText className="h-8 w-8" />;
    if (type.includes('zip') || type.includes('rar') || type.includes('archive')) return <Archive className="h-8 w-8" />;
    if (type.includes('text') || name.endsWith('.txt') || name.endsWith('.doc') || name.endsWith('.docx')) return <FileText className="h-8 w-8" />;

    return <File className="h-8 w-8" />;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-2">
      {/* Document container */}
      <div className="flex items-center gap-3 p-3 bg-muted rounded-lg max-w-sm cursor-pointer hover:bg-muted/80 transition-colors">
        {/* File icon */}
        <div className="text-muted-foreground flex-shrink-0">
          {getFileIcon(document.mimeType, document.filename)}
        </div>

        {/* File info */}
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium truncate">
            {document.filename || 'Document'}
          </div>
          <div className="text-xs text-muted-foreground">
            {formatFileSize(document.size)}
            {document.mimeType && (
              <span className="ml-1">• {document.mimeType.split('/')[1]?.toUpperCase()}</span>
            )}
          </div>
        </div>

        {/* Download button */}
        <Button
          size="sm"
          variant="secondary"
          className="h-8 w-8 p-0 flex-shrink-0"
          onClick={handleDownload}
        >
          <Download className="h-4 w-4" />
        </Button>
      </div>

      {/* Thumbnail if available */}
      {document.thumbnail && (
        <div className="max-w-xs">
          <img
            src={`data:image/jpeg;base64,${document.thumbnail}`}
            alt="Document thumbnail"
            className="w-full h-auto rounded border border-border"
          />
        </div>
      )}

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}
