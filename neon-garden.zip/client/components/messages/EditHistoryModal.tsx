import React from 'react';
import { Message, MessageEdit } from '../../services/database';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatTime } from '../../lib/utils';
import { Clock, Edit } from 'lucide-react';

interface EditHistoryModalProps {
  message: Message;
  editHistory: MessageEdit[];
  onClose: () => void;
}

export function EditHistoryModal({ message, editHistory, onClose }: EditHistoryModalProps) {
  const sortedHistory = [...editHistory].sort((a, b) => 
    new Date(b.editDate).getTime() - new Date(a.editDate).getTime()
  );

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Edit className="h-5 w-5" />
            Edit History
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh]">
          <div className="space-y-4">
            {/* Current version */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm font-medium">Current Version</span>
                {message.editDate && (
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {formatTime(message.editDate)}
                  </div>
                )}
              </div>
              <div className="text-sm bg-muted p-3 rounded border-l-2 border-green-500">
                {message.text || '<empty message>'}
              </div>
            </div>

            {/* Edit history */}
            {sortedHistory.map((edit, index) => (
              <div key={edit.id} className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full" />
                  <span className="text-sm font-medium">
                    Version {sortedHistory.length - index}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {formatTime(edit.editDate)}
                  </div>
                </div>
                <div className="text-sm bg-muted p-3 rounded border-l-2 border-orange-500">
                  {edit.previousText || '<empty message>'}
                </div>
                {edit.editReason && (
                  <div className="mt-2 text-xs text-muted-foreground">
                    Reason: {edit.editReason}
                  </div>
                )}
              </div>
            ))}

            {/* Original message */}
            {sortedHistory.length > 0 && (
              <div className="border rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span className="text-sm font-medium">Original Message</span>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {formatTime(message.date)}
                  </div>
                </div>
                <div className="text-sm bg-muted p-3 rounded border-l-2 border-blue-500">
                  {sortedHistory[sortedHistory.length - 1]?.previousText || '<empty message>'}
                </div>
              </div>
            )}

            {editHistory.length === 0 && (
              <div className="text-center text-muted-foreground py-8">
                <Edit className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No edit history available</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
