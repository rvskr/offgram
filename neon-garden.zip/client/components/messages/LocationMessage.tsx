import React from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { MapPin, ExternalLink } from 'lucide-react';

interface LocationMessageProps {
  message: Message;
}

export function LocationMessage({ message }: LocationMessageProps) {
  const location = message.media?.[0];
  if (!location) {
    return (
      <div className="text-sm text-muted-foreground">
        📍 Location (unavailable)
      </div>
    );
  }

  const openInMaps = () => {
    const url = `https://www.google.com/maps?q=${location.latitude},${location.longitude}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-2">
      {/* Location container */}
      <div className="max-w-sm rounded-lg overflow-hidden border border-border">
        {/* Map placeholder */}
        <div className="h-32 bg-muted flex items-center justify-center cursor-pointer hover:bg-muted/80 transition-colors" onClick={openInMaps}>
          <div className="text-center text-muted-foreground">
            <MapPin className="h-8 w-8 mx-auto mb-2" />
            <div className="text-sm font-medium">Location</div>
            <div className="text-xs">
              {location.latitude?.toFixed(6)}, {location.longitude?.toFixed(6)}
            </div>
          </div>
        </div>

        {/* Location info */}
        <div className="p-3 space-y-2">
          {location.title && (
            <div className="font-medium text-sm">
              {location.title}
            </div>
          )}
          
          {location.address && (
            <div className="text-sm text-muted-foreground">
              {location.address}
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              {location.latitude?.toFixed(6)}, {location.longitude?.toFixed(6)}
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={openInMaps}
              className="h-7"
            >
              <ExternalLink className="h-3 w-3 mr-1" />
              Open
            </Button>
          </div>

          {location.provider && (
            <div className="text-xs text-muted-foreground">
              via {location.provider}
            </div>
          )}
        </div>
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}
