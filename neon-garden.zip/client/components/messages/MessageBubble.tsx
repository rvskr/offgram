import React, { useState } from 'react';
import { MessageType, Message, MessageEdit, MessageStatus } from '../../services/database';
import { formatTime } from '../../lib/utils';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreVertical, Edit, Trash2, Reply, Forward, Copy, History } from 'lucide-react';
import { cn } from '@/lib/utils';

// Import message type components
import { TextMessage } from './TextMessage';
import { PhotoMessage } from './PhotoMessage';
import { VideoMessage } from './VideoMessage';
import { AudioMessage } from './AudioMessage';
import { VoiceMessage } from './VoiceMessage';
import { VideoNoteMessage } from './VideoNoteMessage';
import { DocumentMessage } from './DocumentMessage';
import { StickerMessage } from './StickerMessage';
import { LocationMessage } from './LocationMessage';
import { ContactMessage } from './ContactMessage';
import { PollMessage } from './PollMessage';
import { DeletedMessage } from './DeletedMessage';
import { EditHistoryModal } from './EditHistoryModal';

interface MessageBubbleProps {
  message: Message;
  editHistory?: MessageEdit[];
  isConsecutive?: boolean;
  onReply?: (messageId: string) => void;
  onEdit?: (messageId: string, newText: string) => void;
  onDelete?: (messageId: string) => void;
  onForward?: (messageId: string) => void;
  onDownloadMedia?: (messageId: string, mediaIndex: number) => void;
}

export function MessageBubble({
  message,
  editHistory = [],
  isConsecutive = false,
  onReply,
  onEdit,
  onDelete,
  onForward,
  onDownloadMedia
}: MessageBubbleProps) {
  const [showEditHistory, setShowEditHistory] = useState(false);

  const handleCopyText = () => {
    if (message.text) {
      navigator.clipboard.writeText(message.text);
    }
  };

  const renderMessageContent = () => {
    if (message.isDeleted) {
      return <DeletedMessage message={message} />;
    }

    switch (message.type) {
      case MessageType.Text:
        return <TextMessage message={message} />;
      case MessageType.Photo:
        return <PhotoMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.Video:
        return <VideoMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.Audio:
        return <AudioMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.Voice:
        return <VoiceMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.VideoNote:
        return <VideoNoteMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.Document:
        return <DocumentMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.Sticker:
        return <StickerMessage message={message} onDownload={onDownloadMedia} />;
      case MessageType.Location:
        return <LocationMessage message={message} />;
      case MessageType.Contact:
        return <ContactMessage message={message} />;
      case MessageType.Poll:
        return <PollMessage message={message} />;
      default:
        return <TextMessage message={message} />;
    }
  };

  const canEdit = message.isOwn && !message.isDeleted && message.type === MessageType.Text;
  const canDelete = message.isOwn && !message.isDeleted;

  return (
    <div className={cn(
      "group flex gap-3 px-4 py-2 hover:bg-accent/30 transition-colors",
      message.isOwn ? "flex-row-reverse" : "flex-row"
    )}>
      {/* Avatar */}
      {!isConsecutive && !message.isOwn && (
        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium">
          {message.fromName?.charAt(0) || 'U'}
        </div>
      )}
      {isConsecutive && !message.isOwn && <div className="w-8" />}

      {/* Message content */}
      <div className={cn(
        "flex flex-col max-w-[70%]",
        message.isOwn ? "items-end" : "items-start"
      )}>
        {/* Sender name */}
        {!isConsecutive && !message.isOwn && (
          <div className="text-sm font-medium text-primary mb-1">
            {message.fromName}
          </div>
        )}

        {/* Reply to message */}
        {message.replyToMessageId && (
          <div className="mb-2 p-2 bg-muted rounded border-l-2 border-primary text-sm">
            <div className="text-primary font-medium">Reply to message</div>
            <div className="text-muted-foreground truncate">Original message content...</div>
          </div>
        )}

        {/* Forwarded message */}
        {message.forwardFromChatId && (
          <div className="mb-1 text-xs text-muted-foreground">
            Forwarded from {message.forwardFromChatId}
          </div>
        )}

        {/* Message bubble */}
        <div className={cn(
          "relative rounded-lg p-3 shadow-sm",
          message.isOwn 
            ? "bg-primary text-primary-foreground" 
            : "bg-background border border-border"
        )}>
          {/* Message content */}
          {renderMessageContent()}

          {/* Message metadata */}
          <div className={cn(
            "flex items-center gap-2 mt-2 text-xs",
            message.isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
          )}>
            {/* Edit indicator */}
            {message.isEdited && (
              <span 
                className="cursor-pointer hover:underline"
                onClick={() => setShowEditHistory(true)}
              >
                edited
              </span>
            )}
            
            {/* Views */}
            {message.views && (
              <span>{message.views.toLocaleString()} views</span>
            )}
            
            {/* Time */}
            <span>{formatTime(message.date)}</span>
            
            {/* Status indicators for own messages */}
            {message.isOwn && (
              <div className="flex items-center">
                {message.status === MessageStatus.Read && (
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                )}
                {message.status === MessageStatus.Delivered && (
                  <div className="w-2 h-2 rounded-full bg-blue-500" />
                )}
                {message.status === MessageStatus.Sent && (
                  <div className="w-2 h-2 rounded-full bg-gray-500" />
                )}
              </div>
            )}
          </div>

          {/* Message actions menu */}
          <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 w-6 p-0 hover:bg-background/20"
                >
                  <MoreVertical className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                {onReply && (
                  <DropdownMenuItem onClick={() => onReply(message.id)}>
                    <Reply className="mr-2 h-4 w-4" />
                    Reply
                  </DropdownMenuItem>
                )}
                
                {onForward && (
                  <DropdownMenuItem onClick={() => onForward(message.id)}>
                    <Forward className="mr-2 h-4 w-4" />
                    Forward
                  </DropdownMenuItem>
                )}
                
                {message.text && (
                  <DropdownMenuItem onClick={handleCopyText}>
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Text
                  </DropdownMenuItem>
                )}

                {message.isEdited && editHistory.length > 0 && (
                  <DropdownMenuItem onClick={() => setShowEditHistory(true)}>
                    <History className="mr-2 h-4 w-4" />
                    Edit History
                  </DropdownMenuItem>
                )}
                
                {canEdit && onEdit && (
                  <DropdownMenuItem onClick={() => onEdit(message.id, message.text || '')}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit
                  </DropdownMenuItem>
                )}
                
                {canDelete && onDelete && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(message.id)}
                    className="text-destructive"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Edit History Modal */}
      {showEditHistory && (
        <EditHistoryModal
          message={message}
          editHistory={editHistory}
          onClose={() => setShowEditHistory(false)}
        />
      )}
    </div>
  );
}
