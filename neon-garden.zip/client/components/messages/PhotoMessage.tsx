import React, { useState } from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { Download, Eye } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PhotoMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function PhotoMessage({ message, onDownload }: PhotoMessageProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showFullSize, setShowFullSize] = useState(false);

  const photo = message.media?.[0];
  if (!photo) {
    return (
      <div className="text-sm text-muted-foreground">
        📷 Photo (unavailable)
      </div>
    );
  }

  const handleDownload = () => {
    if (onDownload) {
      onDownload(message.id, 0);
    }
  };

  return (
    <div className="space-y-2">
      {/* Photo container */}
      <div className="relative max-w-xs rounded-lg overflow-hidden bg-muted">
        {photo.thumbnail ? (
          <img
            src={`data:image/jpeg;base64,${photo.thumbnail}`}
            alt="Photo"
            className={cn(
              "w-full h-auto cursor-pointer transition-opacity",
              imageLoaded ? "opacity-100" : "opacity-50"
            )}
            style={{
              maxWidth: photo.width ? `${Math.min(photo.width, 300)}px` : '300px',
              maxHeight: photo.height ? `${Math.min(photo.height, 400)}px` : '400px'
            }}
            onLoad={() => setImageLoaded(true)}
            onClick={() => setShowFullSize(true)}
          />
        ) : (
          <div 
            className="flex items-center justify-center bg-muted text-muted-foreground cursor-pointer"
            style={{
              width: photo.width ? `${Math.min(photo.width, 300)}px` : '300px',
              height: photo.height ? `${Math.min(photo.height, 400)}px` : '200px'
            }}
            onClick={() => setShowFullSize(true)}
          >
            <div className="text-center">
              <Eye className="h-8 w-8 mx-auto mb-2" />
              <div className="text-sm">Click to view</div>
              <div className="text-xs text-muted-foreground">
                {photo.width}×{photo.height}
              </div>
            </div>
          </div>
        )}

        {/* Download button overlay */}
        <div className="absolute top-2 right-2 opacity-0 hover:opacity-100 transition-opacity">
          <Button
            size="sm"
            variant="secondary"
            className="h-8 w-8 p-0"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>

        {/* Photo info overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-2 text-xs">
          <div className="flex justify-between items-center">
            <span>
              {photo.width}×{photo.height}
            </span>
            <span>
              {formatFileSize(photo.size)}
            </span>
          </div>
        </div>
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}

      {/* Full size modal */}
      {showFullSize && (
        <div 
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
          onClick={() => setShowFullSize(false)}
        >
          <div className="relative max-w-screen-lg max-h-screen-lg">
            <img
              src={photo.thumbnail ? `data:image/jpeg;base64,${photo.thumbnail}` : '/placeholder.svg'}
              alt="Photo"
              className="max-w-full max-h-full object-contain"
            />
            <Button
              className="absolute top-4 right-4"
              variant="secondary"
              onClick={(e) => {
                e.stopPropagation();
                handleDownload();
              }}
            >
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
