import React, { useState } from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { BarChart3, Users, Lock } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface PollMessageProps {
  message: Message;
}

export function PollMessage({ message }: PollMessageProps) {
  const poll = message.media?.[0];
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([]);
  const [hasVoted, setHasVoted] = useState(false);

  if (!poll) {
    return (
      <div className="text-sm text-muted-foreground">
        📊 Poll (unavailable)
      </div>
    );
  }

  const handleVote = () => {
    if (selectedAnswers.length > 0) {
      setHasVoted(true);
      // Here you would send the vote to the server
      console.log('Voted for:', selectedAnswers);
    }
  };

  const handleAnswerChange = (answerId: string, checked: boolean) => {
    if (poll.multipleChoice) {
      setSelectedAnswers(prev => 
        checked 
          ? [...prev, answerId]
          : prev.filter(id => id !== answerId)
      );
    } else {
      setSelectedAnswers(checked ? [answerId] : []);
    }
  };

  // Mock vote counts for demonstration
  const totalVotes = 100;
  const getVotePercentage = (index: number) => {
    const mockVotes = [45, 30, 20, 5];
    return mockVotes[index] || 0;
  };

  return (
    <div className="space-y-3">
      {/* Poll container */}
      <div className="p-4 bg-muted rounded-lg max-w-md">
        {/* Poll header */}
        <div className="flex items-start gap-2 mb-3">
          <BarChart3 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <div className="font-medium text-sm mb-1">
              {poll.question}
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {poll.multipleChoice && (
                <span>Multiple choice</span>
              )}
              {poll.closed && (
                <>
                  <Lock className="h-3 w-3" />
                  <span>Closed</span>
                </>
              )}
              <Users className="h-3 w-3" />
              <span>{totalVotes} votes</span>
            </div>
          </div>
        </div>

        {/* Poll options */}
        <div className="space-y-2">
          {poll.answers?.map((answer, index) => {
            const votePercentage = getVotePercentage(index);
            const isSelected = selectedAnswers.includes(answer.option);

            return (
              <div key={answer.option} className="space-y-1">
                {!poll.closed && !hasVoted ? (
                  <div className="flex items-center space-x-2">
                    {poll.multipleChoice ? (
                      <Checkbox
                        id={answer.option}
                        checked={isSelected}
                        onCheckedChange={(checked) => 
                          handleAnswerChange(answer.option, checked as boolean)
                        }
                      />
                    ) : (
                      <RadioGroupItem
                        value={answer.option}
                        id={answer.option}
                        checked={isSelected}
                        onClick={() => handleAnswerChange(answer.option, !isSelected)}
                      />
                    )}
                    <Label 
                      htmlFor={answer.option}
                      className="text-sm cursor-pointer flex-1"
                    >
                      {answer.text}
                    </Label>
                  </div>
                ) : (
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-sm">
                      <span className={isSelected ? "font-medium" : ""}>
                        {answer.text}
                      </span>
                      <span className="text-muted-foreground">
                        {votePercentage}%
                      </span>
                    </div>
                    <Progress 
                      value={votePercentage} 
                      className="h-2"
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Vote button */}
        {!poll.closed && !hasVoted && selectedAnswers.length > 0 && (
          <Button
            onClick={handleVote}
            className="w-full mt-3"
            size="sm"
          >
            Vote
          </Button>
        )}

        {hasVoted && (
          <div className="text-center text-sm text-muted-foreground mt-3">
            Thank you for voting!
          </div>
        )}
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}
