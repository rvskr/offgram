import React from 'react';
import { Message } from '../../services/database';

interface StickerMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function StickerMessage({ message, onDownload }: StickerMessageProps) {
  const sticker = message.media?.[0];
  if (!sticker) {
    return (
      <div className="text-sm text-muted-foreground">
        😀 Sticker (unavailable)
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {/* Sticker container */}
      <div className="max-w-[150px]">
        {sticker.thumbnail ? (
          <img
            src={`data:image/jpeg;base64,${sticker.thumbnail}`}
            alt={sticker.alt || 'Sticker'}
            className="w-full h-auto cursor-pointer hover:scale-105 transition-transform"
            style={{
              maxWidth: '150px',
              maxHeight: '150px'
            }}
            onClick={() => onDownload?.(message.id, 0)}
          />
        ) : (
          <div 
            className="flex items-center justify-center bg-muted text-muted-foreground cursor-pointer rounded-lg"
            style={{ width: '150px', height: '150px' }}
            onClick={() => onDownload?.(message.id, 0)}
          >
            <div className="text-center">
              <div className="text-4xl mb-2">😀</div>
              <div className="text-xs">Sticker</div>
              {sticker.alt && (
                <div className="text-xs text-muted-foreground">
                  {sticker.alt}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}
