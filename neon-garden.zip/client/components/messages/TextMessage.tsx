import React from 'react';
import { Message } from '../../services/database';

interface TextMessageProps {
  message: Message;
}

export function TextMessage({ message }: TextMessageProps) {
  return (
    <div className="text-sm leading-relaxed whitespace-pre-wrap">
      {message.text || 'Empty message'}
    </div>
  );
}
