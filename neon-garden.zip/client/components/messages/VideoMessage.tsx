import React, { useState, useRef } from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { Download, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { cn } from '@/lib/utils';

interface VideoMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function VideoMessage({ message, onDownload }: VideoMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const video = message.media?.[0];
  if (!video) {
    return (
      <div className="text-sm text-muted-foreground">
        🎥 Video (unavailable)
      </div>
    );
  }

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMuteToggle = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload(message.id, 0);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-2">
      {/* Video container */}
      <div className="relative max-w-md rounded-lg overflow-hidden bg-black">
        {video.thumbnail ? (
          <div className="relative">
            {/* Thumbnail */}
            <img
              src={`data:image/jpeg;base64,${video.thumbnail}`}
              alt="Video thumbnail"
              className="w-full h-auto"
              style={{
                maxWidth: video.width ? `${Math.min(video.width, 400)}px` : '400px',
                maxHeight: video.height ? `${Math.min(video.height, 300)}px` : '300px'
              }}
            />
            
            {/* Play button overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                size="lg"
                className="rounded-full bg-black/50 hover:bg-black/70 text-white"
                onClick={handlePlayPause}
              >
                <Play className="h-8 w-8 ml-1" />
              </Button>
            </div>

            {/* Duration overlay */}
            <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
              {formatDuration(video.duration || 0)}
            </div>
          </div>
        ) : (
          <div 
            className="flex items-center justify-center bg-muted text-muted-foreground cursor-pointer"
            style={{
              width: video.width ? `${Math.min(video.width, 400)}px` : '400px',
              height: video.height ? `${Math.min(video.height, 300)}px` : '200px'
            }}
            onClick={handlePlayPause}
          >
            <div className="text-center">
              <Play className="h-12 w-12 mx-auto mb-2" />
              <div className="text-sm">Video</div>
              <div className="text-xs text-muted-foreground">
                {video.width}×{video.height}
              </div>
              {video.duration && (
                <div className="text-xs text-muted-foreground">
                  {formatDuration(video.duration)}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Hidden video element for future streaming */}
        <video
          ref={videoRef}
          className="hidden"
          onTimeUpdate={handleTimeUpdate}
          onEnded={() => setIsPlaying(false)}
        />

        {/* Controls overlay */}
        <div className="absolute top-2 right-2 flex gap-2">
          <Button
            size="sm"
            variant="secondary"
            className="h-8 w-8 p-0 bg-black/50 hover:bg-black/70"
            onClick={handleMuteToggle}
          >
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
          <Button
            size="sm"
            variant="secondary"
            className="h-8 w-8 p-0 bg-black/50 hover:bg-black/70"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>

        {/* Video info */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent text-white p-2">
          <div className="flex justify-between items-center text-xs">
            <span>
              {video.width}×{video.height}
            </span>
            <span>
              {formatFileSize(video.size)}
            </span>
          </div>
        </div>
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
