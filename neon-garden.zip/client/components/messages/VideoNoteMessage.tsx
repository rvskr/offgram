import React, { useState, useRef } from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { Play, Pause } from 'lucide-react';
import { cn } from '@/lib/utils';

interface VideoNoteMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function VideoNoteMessage({ message, onDownload }: VideoNoteMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const videoNote = message.media?.[0];
  if (!videoNote) {
    return (
      <div className="text-sm text-muted-foreground">
        ⭕ Video note (unavailable)
      </div>
    );
  }

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = videoNote.duration ? (currentTime / videoNote.duration) * 100 : 0;

  return (
    <div className="space-y-2">
      {/* Video note container */}
      <div className="relative">
        {/* Circular video container */}
        <div 
          className="relative rounded-full overflow-hidden bg-black cursor-pointer"
          style={{ width: '200px', height: '200px' }}
          onClick={handlePlayPause}
        >
          {videoNote.thumbnail ? (
            <img
              src={`data:image/jpeg;base64,${videoNote.thumbnail}`}
              alt="Video note"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-muted text-muted-foreground">
              <div className="text-center">
                <div className="text-2xl mb-2">⭕</div>
                <div className="text-xs">Video Note</div>
              </div>
            </div>
          )}

          {/* Play button overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <Button
              size="lg"
              className={cn(
                "rounded-full bg-black/50 hover:bg-black/70 text-white transition-opacity",
                isPlaying ? "opacity-0" : "opacity-100"
              )}
            >
              <Play className="h-8 w-8 ml-1" />
            </Button>
          </div>

          {/* Progress ring */}
          {isPlaying && progress > 0 && (
            <div className="absolute inset-0">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="48"
                  fill="none"
                  stroke="rgba(255,255,255,0.3)"
                  strokeWidth="2"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="48"
                  fill="none"
                  stroke="white"
                  strokeWidth="2"
                  strokeDasharray={`${progress * 3.01} 301`}
                  className="transition-all duration-100"
                />
              </svg>
            </div>
          )}

          {/* Duration indicator */}
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-2 py-1 rounded text-xs">
            {isPlaying ? formatTime(currentTime) : formatTime(videoNote.duration || 0)}
          </div>
        </div>

        {/* Hidden video element */}
        <video
          ref={videoRef}
          className="hidden"
          onTimeUpdate={handleTimeUpdate}
          onEnded={() => setIsPlaying(false)}
          loop={false}
        />
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}
    </div>
  );
}
