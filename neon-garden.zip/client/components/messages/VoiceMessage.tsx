import React, { useState, useRef } from 'react';
import { Message } from '../../services/database';
import { Button } from '@/components/ui/button';
import { Play, Pause, Mic } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface VoiceMessageProps {
  message: Message;
  onDownload?: (messageId: string, mediaIndex: number) => void;
}

export function VoiceMessage({ message, onDownload }: VoiceMessageProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const voice = message.media?.[0];
  if (!voice) {
    return (
      <div className="text-sm text-muted-foreground">
        🎤 Voice message (unavailable)
      </div>
    );
  }

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="space-y-2">
      {/* Voice player */}
      <div className="flex items-center gap-3 p-3 bg-muted rounded-full max-w-xs">
        {/* Play/Pause button */}
        <Button
          size="sm"
          variant="secondary"
          className="h-8 w-8 rounded-full flex-shrink-0"
          onClick={handlePlayPause}
        >
          {isPlaying ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3 ml-0.5" />}
        </Button>

        {/* Voice visualizer and progress */}
        <div className="flex-1 flex items-center gap-2">
          <Mic className="h-4 w-4 text-primary flex-shrink-0" />
          
          {/* Voice waveform placeholder */}
          <div className="flex-1 flex items-center gap-0.5">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className="bg-primary/30 rounded-full transition-colors"
                style={{
                  width: '2px',
                  height: `${8 + Math.random() * 16}px`,
                  backgroundColor: i / 20 < progress / 100 ? 'hsl(var(--primary))' : undefined
                }}
              />
            ))}
          </div>

          {/* Duration */}
          <span className="text-xs text-muted-foreground flex-shrink-0">
            {isPlaying ? formatTime(currentTime) : formatTime(voice.duration || 0)}
          </span>
        </div>
      </div>

      {/* Caption */}
      {message.text && (
        <div className="text-sm leading-relaxed">
          {message.text}
        </div>
      )}

      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
        className="hidden"
      />
    </div>
  );
}
