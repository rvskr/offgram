import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { AlertCircle, ArrowLeft, Shield } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { telegramService } from '../services/telegram';
import CredentialsSetup from './CredentialsSetup';
import { ErrorDisplay } from '../components/ErrorDisplay';

type AuthStep = 'phone' | 'code' | '2fa';

interface AuthState {
  phone: string;
  code: string;
  password: string;
  error: string;
  phoneCodeHash: string;
}

export default function Auth() {
  const [step, setStep] = useState<AuthStep>('phone');
  const [loading, setLoading] = useState(false);
  const [authState, setAuthState] = useState<AuthState>({
    phone: '',
    code: '',
    password: '',
    error: '',
    phoneCodeHash: ''
  });
  const [showCredentialsSetup, setShowCredentialsSetup] = useState(false);

  useEffect(() => {
    // Connect to Telegram on component mount
    const connectToTelegram = async () => {
      try {
        await telegramService.connect();
      } catch (error) {
        console.error('Failed to connect to Telegram:', error);
        setAuthState(prev => ({
          ...prev,
          error: 'Failed to connect to Telegram. Please check your internet connection.'
        }));
      }
    };

    connectToTelegram();

    // Cleanup on unmount
    return () => {
      telegramService.disconnect();
    };
  }, []);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authState.phone) {
      setAuthState(prev => ({ ...prev, error: 'Please enter your phone number' }));
      return;
    }

    setLoading(true);
    setAuthState(prev => ({ ...prev, error: '' }));

    try {
      const result = await telegramService.sendCode(authState.phone);
      setAuthState(prev => ({ ...prev, phoneCodeHash: result.phoneCodeHash }));
      setStep('code');
    } catch (error: any) {
      const errorMessage = error.message || 'Failed to send code. Please try again.';

      // Check if it's a credentials error (status 503 = Service Unavailable, 401 = Unauthorized)
      if (error.status === 503 || error.status === 401 ||
          errorMessage.includes('API credentials') ||
          errorMessage.includes('TELEGRAM_API_ID and TELEGRAM_API_HASH')) {
        setShowCredentialsSetup(true);
        return;
      }

      // Handle AUTH_RESTART errors (401) by clearing local session
      if (error.status === 401 && (errorMessage.includes('AUTH_RESTART') || errorMessage.includes('Authentication session was reset'))) {
        // Clear any stored session data
        localStorage.removeItem('telegram_session_id');
        localStorage.removeItem('telegram_phone_number');
        setAuthState(prev => ({
          ...prev,
          error: 'Authentication session was reset. Please try again.'
        }));
        return;
      }

      // Handle rate limiting (429) and flood wait errors
      if (error.status === 429 || errorMessage.includes('Too many requests') || errorMessage.includes('Please wait')) {
        setAuthState(prev => ({
          ...prev,
          error: errorMessage
        }));
        return;
      }

      setAuthState(prev => ({
        ...prev,
        error: errorMessage
      }));
    } finally {
      setLoading(false);
    }
  };

  const handleCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authState.code) {
      setAuthState(prev => ({ ...prev, error: 'Please enter the verification code' }));
      return;
    }

    setLoading(true);
    setAuthState(prev => ({ ...prev, error: '' }));

    try {
      const result = await telegramService.signIn(authState.code, authState.phoneCodeHash);

      if (result.success) {
        window.location.href = '/chats';
      } else if (result.requires2FA) {
        setStep('2fa');
      } else {
        setAuthState(prev => ({ ...prev, error: 'Invalid code. Please try again.' }));
      }
    } catch (error: any) {
      const errorMessage = error.message || 'Invalid code. Please try again.';

      // Check if it's a credentials error
      if (error.status === 503 || error.status === 401 ||
          errorMessage.includes('API credentials') ||
          errorMessage.includes('TELEGRAM_API_ID and TELEGRAM_API_HASH')) {
        setShowCredentialsSetup(true);
        return;
      }

      setAuthState(prev => ({
        ...prev,
        error: errorMessage
      }));
    } finally {
      setLoading(false);
    }
  };

  const handle2FASubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authState.password) {
      setAuthState(prev => ({ ...prev, error: 'Please enter your 2FA password' }));
      return;
    }

    setLoading(true);
    setAuthState(prev => ({ ...prev, error: '' }));

    try {
      const result = await telegramService.checkPassword(authState.password);

      if (result.success) {
        window.location.href = '/chats';
      } else {
        setAuthState(prev => ({ ...prev, error: 'Invalid password. Please try again.' }));
      }
    } catch (error: any) {
      const errorMessage = error.message || 'Invalid password. Please try again.';

      // Check if it's a credentials error (status 503 = Service Unavailable, 401 = Unauthorized)
      if (error.status === 503 || error.status === 401 ||
          errorMessage.includes('API credentials') ||
          errorMessage.includes('TELEGRAM_API_ID and TELEGRAM_API_HASH')) {
        setShowCredentialsSetup(true);
        return;
      }

      setAuthState(prev => ({
        ...prev,
        error: errorMessage
      }));
    } finally {
      setLoading(false);
    }
  };

  const goBack = () => {
    if (step === 'code') setStep('phone');
    if (step === '2fa') setStep('code');
    setAuthState(prev => ({ ...prev, error: '' }));
  };

  const updateAuthState = (field: keyof AuthState, value: string) => {
    setAuthState(prev => ({ ...prev, [field]: value, error: '' }));
  };

  // Show credentials setup if needed
  if (showCredentialsSetup) {
    return <CredentialsSetup />;
  }

  return (
    <div className="min-h-screen bg-telegram-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        {/* Logo/Header */}
        <div className="text-center space-y-4">
          <div className="w-20 h-20 mx-auto bg-primary rounded-full flex items-center justify-center">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="white">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.16 1.84-.78 6.4-1.1 8.48-.14.88-.42 1.18-.68 1.21-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
            </svg>
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Telegram</h1>
            <p className="text-telegram-text-secondary mt-2">
              {step === 'phone' && 'Please confirm your country code and enter your phone number.'}
              {step === 'code' && `We've sent the code to ${authState.phone}`}
              {step === '2fa' && 'Please enter your 2FA password'}
            </p>
          </div>
        </div>

        {/* Auth Form */}
        <Card className="border-border/50 shadow-lg">
          <CardHeader className="space-y-1">
            <div className="flex items-center space-x-2">
              {step !== 'phone' && (
                <Button variant="ghost" size="sm" onClick={goBack} className="h-8 w-8 p-0">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              )}
              <CardTitle className="text-xl">
                {step === 'phone' && 'Your Phone'}
                {step === 'code' && 'Enter Code'}
                {step === '2fa' && 'Two-Step Verification'}
              </CardTitle>
            </div>
            <CardDescription>
              {step === 'phone' && 'Telegram will send you an SMS with a verification code.'}
              {step === 'code' && 'Enter the 5-digit code we sent you.'}
              {step === '2fa' && 'Your account has two-step verification enabled.'}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            {authState.error && (
              <ErrorDisplay error={authState.error} />
            )}

            {step === 'phone' && (
              <form onSubmit={handlePhoneSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={authState.phone}
                    onChange={(e) => updateAuthState('phone', e.target.value)}
                    className="text-center text-lg"
                    autoFocus
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? 'Sending...' : 'Next'}
                </Button>
              </form>
            )}

            {step === 'code' && (
              <form onSubmit={handleCodeSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="code">Verification Code</Label>
                  <Input
                    id="code"
                    type="text"
                    placeholder="12345"
                    value={authState.code}
                    onChange={(e) => updateAuthState('code', e.target.value)}
                    className="text-center text-lg tracking-widest"
                    maxLength={5}
                    autoFocus
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? 'Verifying...' : 'Continue'}
                </Button>
                <Button 
                  type="button" 
                  variant="ghost" 
                  className="w-full" 
                  onClick={() => setStep('phone')}
                >
                  Didn't receive the code?
                </Button>
              </form>
            )}

            {step === '2fa' && (
              <form onSubmit={handle2FASubmit} className="space-y-4">
                <div className="flex justify-center mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={authState.password}
                    onChange={(e) => updateAuthState('password', e.target.value)}
                    className="text-center"
                    autoFocus
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? 'Verifying...' : 'Continue'}
                </Button>
                <Button 
                  type="button" 
                  variant="ghost" 
                  className="w-full text-sm" 
                >
                  Forgot password?
                </Button>
              </form>
            )}
          </CardContent>
        </Card>

        <p className="text-center text-sm text-telegram-text-secondary">
          By signing up, you agree to Telegram's{' '}
          <a href="#" className="text-primary hover:underline">Terms of Service</a>{' '}
          and{' '}
          <a href="#" className="text-primary hover:underline">Privacy Policy</a>.
        </p>
      </div>
    </div>
  );
}
