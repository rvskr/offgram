import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { telegramService } from '../services/telegram';
import { Message, MessageType, MessageStatus } from '../services/database';
import { MessageBubble } from '../components/messages/MessageBubble';
import { messageSyncService } from '../services/messageSync';
import { formatTime } from '../lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  Send, 
  Paperclip, 
  Smile,
  Mic,
  Check,
  CheckCheck
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ChatData {
  id: string;
  name: string;
  avatar?: string;
  isOnline?: boolean;
  lastSeen?: string;
  isGroup?: boolean;
  memberCount?: number;
}

export default function Chat() {
  const { chatId } = useParams<{ chatId: string }>();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatData, setChatData] = useState<ChatData | null>(null);
  const [loading, setLoading] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [error, setError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [lastMessageId, setLastMessageId] = useState<string>('');
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const loadChatData = async () => {
      if (!chatId) return;

      try {
        setLoading(true);
        setError('');

        // Ensure we're connected to Telegram
        if (!telegramService.isClientConnected()) {
          console.log('No session, redirecting to auth');
          return;
        }

        // Load messages using sync service
        const messageHistory = await messageSyncService.syncMessages(chatId, { limit: 50 });
        console.log('Messages loaded:', messageHistory.map(m => ({
          id: m.id,
          text: m.text?.substring(0, 20),
          isOwn: m.isOwn,
          fromId: m.fromId,
          fromName: m.fromName
        })));
        setMessages(messageHistory.reverse()); // Reverse to show oldest first
        setHasMoreMessages(messageHistory.length >= 50); // Assume more if we got full limit

        // Load chat data from database
        const chats = await messageSyncService.syncChats();
        const currentChat = chats.find(chat => chat.id === chatId);

        if (currentChat) {
          setChatData({
            id: currentChat.id,
            name: currentChat.name,
            isOnline: false, // Will be determined from server
            isGroup: currentChat.type === 'group' || currentChat.type === 'supergroup',
            avatar: currentChat.avatar
          });
        } else {
          // Fallback chat data
          setChatData({
            id: chatId,
            name: 'Unknown Chat',
            isOnline: false
          });
        }
      } catch (error: any) {
        console.error('Failed to load chat data:', error);
        setError(error.message || 'Failed to load chat');

        // Set fallback data
        setChatData({
          id: chatId,
          name: 'Chat',
          isOnline: false
        });
      } finally {
        setLoading(false);
      }
    };

    loadChatData();
  }, [chatId]);

  // Scroll to bottom only when needed
  useEffect(() => {
    if (!loading && messages.length > 0) {
      // Scroll only once when loading is complete
      setTimeout(() => scrollToBottom(), 200);
    }
  }, [loading]);

  // Polling для обновлений сообщений (реже)
  useEffect(() => {
    if (!chatId || !telegramService.isClientConnected() || loading) return;

    const pollForUpdates = async () => {
      try {
        const newMessages = await messageSyncService.syncNewMessages(chatId, 5);

        if (newMessages.length > 0) {
          console.log('Found new messages:', newMessages.length);
          setMessages(prev => [...prev, ...newMessages]);
        }
      } catch (error) {
        console.error('Failed to poll for updates:', error);
      }
    };

    const interval = setInterval(pollForUpdates, 10000); // Проверяем каждые 10 секунд
    return () => clearInterval(interval);
  }, [chatId, loading]);

  const scrollToBottom = () => {
    setTimeout(() => {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
        console.log('Scrolled to bottom');
      }
    }, 100);
  };

  const loadOlderMessages = async () => {
    console.log('loadOlderMessages called:', {
      loadingOlder,
      hasMoreMessages,
      messagesLength: messages.length
    });

    if (loadingOlder || !hasMoreMessages || messages.length === 0) {
      console.log('loadOlderMessages aborted due to conditions');
      return;
    }

    console.log('Starting to load older messages...');
    setLoadingOlder(true);
    try {
      const oldestMessage = messages[0];
      console.log('Oldest message:', {
        id: oldestMessage.id,
        date: oldestMessage.date,
        text: oldestMessage.text?.substring(0, 50)
      });

      // Ensure we pass a proper Date object
      const messageDate = oldestMessage.date instanceof Date ? oldestMessage.date : new Date(oldestMessage.date);

      if (isNaN(messageDate.getTime())) {
        console.error('Invalid date in oldest message:', oldestMessage.date);
        setLoadingOlder(false);
        return;
      }

      console.log('Calling messageSyncService.loadOlderMessages with date:', messageDate);
      const olderMessages = await messageSyncService.loadOlderMessages(
        chatId!,
        messageDate,
        20
      );

      if (olderMessages.length > 0) {
        console.log('Loaded older messages:', olderMessages.length);

        // Save current scroll position
        const container = messagesContainerRef.current;
        const previousScrollHeight = container?.scrollHeight || 0;

        setMessages(prev => [...olderMessages.reverse(), ...prev]);

        // Restore scroll position after new messages are added
        setTimeout(() => {
          if (container) {
            const newScrollHeight = container.scrollHeight;
            const scrollDiff = newScrollHeight - previousScrollHeight;
            container.scrollTop = container.scrollTop + scrollDiff;
            console.log('Adjusted scroll position by:', scrollDiff);
          }
        }, 100);

        // If we got less than requested, we've reached the end
        if (olderMessages.length < 20) {
          setHasMoreMessages(false);
        }
      } else {
        // Only set hasMoreMessages to false if we didn't get any messages
        // This could be due to errors, so we should keep trying
        console.log('No older messages loaded - keeping pagination enabled for retry');
      }
    } catch (error) {
      console.error('Failed to load older messages:', error);
      // Don't disable pagination on error - user might want to retry
      // Only disable if we consistently get no messages
    } finally {
      setLoadingOlder(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !chatId || sendingMessage) return;

    const messageText = message;
    setMessage('');
    setSendingMessage(true);

    // Optimistically add message to UI
    const optimisticMessage: Message = {
      id: 'temp-' + Date.now().toString(),
      telegramId: 0,
      chatId: chatId,
      fromId: 'self',
      fromName: 'You',
      type: MessageType.Text,
      text: messageText,
      media: [],
      date: new Date(),
      isOwn: true,
      status: MessageStatus.Sending,
      isDeleted: false,
      isEdited: false,
      reactions: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setMessages(prev => [...prev, optimisticMessage]);

    try {
      await telegramService.sendMessage(chatId, messageText);

      // Update the message to show as delivered
      setMessages(prev => prev.map(msg =>
        msg.id === optimisticMessage.id
          ? { ...msg, isDelivered: true, id: Date.now().toString() }
          : msg
      ));
    } catch (error: any) {
      console.error('Failed to send message:', error);

      // Remove the failed message and show error
      setMessages(prev => prev.filter(msg => msg.id !== optimisticMessage.id));
      setError('Failed to send message');
      setMessage(messageText); // Restore the message text
    } finally {
      setSendingMessage(false);
    }
  };

  const handleReply = (messageId: string) => {
    // TODO: Implement reply functionality
    console.log('Reply to message:', messageId);
  };

  const handleEdit = async (messageId: string, newText: string) => {
    try {
      // TODO: Implement edit functionality
      console.log('Edit message:', messageId, newText);
      // await messageSyncService.editMessage(messageId, newText);
    } catch (error) {
      console.error('Failed to edit message:', error);
    }
  };

  const handleDelete = async (messageId: string) => {
    try {
      // TODO: Implement delete functionality
      console.log('Delete message:', messageId);
      // await messageSyncService.deleteMessage(messageId);
    } catch (error) {
      console.error('Failed to delete message:', error);
    }
  };

  const handleForward = (messageId: string) => {
    // TODO: Implement forward functionality
    console.log('Forward message:', messageId);
  };

  const handleDownloadMedia = async (messageId: string, mediaIndex: number) => {
    try {
      const url = await messageSyncService.downloadAndCacheMedia(messageId, mediaIndex);
      if (url) {
        // Создаем ссылку для с��ачивания
        const a = document.createElement('a');
        a.href = url;
        a.download = 'media_file';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Failed to download media:', error);
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500',
      'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500'
    ];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };


  if (loading) {
    return (
      <div className="h-screen bg-telegram-chat-bg flex items-center justify-center">
        <div className="text-center">
          <div className="h-12 w-12 mx-auto mb-4 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground">Loading chat...</p>
        </div>
      </div>
    );
  }

  if (!chatData) {
    return (
      <div className="h-screen bg-telegram-chat-bg flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-foreground mb-2">Chat not found</h2>
          <Link to="/chats" className="text-primary hover:underline">
            Return to chats
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-telegram-chat-bg flex flex-col">
      {/* Chat Header */}
      <div className="bg-telegram-sidebar border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link to="/chats">
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>

            <div className="relative">
              <Avatar className="h-10 w-10">
                {chatData.avatar?.hasPhoto ? (
                  <AvatarImage
                    src={`/api/telegram/avatar/${chatData.avatar.photoId}`}
                    alt={chatData.name}
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                ) : null}
                <AvatarFallback className={`${getAvatarColor(chatData.name)} text-white text-sm`}>
                  {getInitials(chatData.name)}
                </AvatarFallback>
              </Avatar>
              {chatData.isOnline && (
                <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-telegram-online border-2 border-background rounded-full" />
              )}
            </div>

            <div>
              <h2 className="font-semibold text-foreground">{chatData.name}</h2>
              <p className="text-sm text-muted-foreground">
                {chatData.isOnline && 'online'}
                {chatData.lastSeen && chatData.lastSeen}
                {chatData.isGroup && `${chatData.memberCount} members`}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Phone className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Video className="h-4 w-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>View Profile</DropdownMenuItem>
                <DropdownMenuItem>Search Messages</DropdownMenuItem>
                <DropdownMenuItem>Mute Notifications</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">
                  Delete Chat
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 relative"
        onScroll={(e) => {
          const container = e.currentTarget;
          const isAtBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 100;
          const isAtTop = container.scrollTop < 100;

          console.log('Scroll event:', {
            scrollTop: container.scrollTop,
            scrollHeight: container.scrollHeight,
            clientHeight: container.clientHeight,
            isAtTop,
            isAtBottom,
            hasMoreMessages,
            loadingOlder
          });

          setShowScrollButton(!isAtBottom);

          // Load older messages when scrolled near top
          if (isAtTop && hasMoreMessages && !loadingOlder && messages.length > 0) {
            console.log('Triggering loadOlderMessages due to scroll');
            loadOlderMessages();
          }
        }}
      >
        {loadingOlder && (
          <div className="text-center py-4">
            <div className="text-sm text-muted-foreground">Loading older messages...</div>
          </div>
        )}

        {!hasMoreMessages && messages.length > 0 && (
          <div className="text-center py-4">
            <div className="text-sm text-muted-foreground">No more messages</div>
          </div>
        )}

        {error && (
          <div className="p-3 mb-4 bg-destructive/10 border border-destructive/20 rounded-lg">
            <p className="text-destructive text-sm">{error}</p>
          </div>
        )}
        {messages.map((msg, index) => {
          const prevMessage = index > 0 ? messages[index - 1] : null;
          const isConsecutive = prevMessage &&
            prevMessage.fromId === msg.fromId &&
            prevMessage.isOwn === msg.isOwn &&
            (new Date(msg.date).getTime() - new Date(prevMessage.date).getTime()) < 60000; // 1 minute

          return (
            <MessageBubble
              key={msg.id}
              message={msg}
              isConsecutive={isConsecutive}
              onReply={handleReply}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onForward={handleForward}
              onDownloadMedia={handleDownloadMedia}
            />
          );
        })}
        <div ref={messagesEndRef} />

        {/* Scroll to bottom button */}
        {showScrollButton && (
          <div className="absolute bottom-4 right-4">
            <Button
              onClick={scrollToBottom}
              size="sm"
              className="rounded-full h-10 w-10 p-0 bg-primary/90 hover:bg-primary shadow-lg"
            >
              ↓
            </Button>
          </div>
        )}
      </div>

      {/* Message Input */}
      <div className="bg-telegram-sidebar border-t border-border p-4">
        <form onSubmit={handleSendMessage} className="flex items-end space-x-2">
          <div className="flex space-x-2">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0" type="button">
              <Paperclip className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 relative">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Write a message..."
              className="pr-16 resize-none bg-background"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage(e);
                }
              }}
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
              type="button"
            >
              <Smile className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex space-x-2">
            {message.trim() ? (
              <Button
                type="submit"
                size="sm"
                className="h-8 w-8 p-0"
                disabled={sendingMessage}
              >
                <Send className="h-4 w-4" />
              </Button>
            ) : (
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" type="button">
                <Mic className="h-4 w-4" />
              </Button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
