import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { telegramService } from '../services/telegram';
import { formatTime } from '../lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Search,
  Menu,
  Settings,
  Moon,
  Sun,
  Edit3,
  MoreVertical,
  Phone,
  Video,
  Archive,
  Bookmark,
  Users,
  LogOut
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Chat {
  id: string;
  name: string;
  lastMessage: string;
  time: string;
  avatar?: string;
  unreadCount?: number;
  isOnline?: boolean;
  isPinned?: boolean;
  isGroup?: boolean;
  lastMessageSender?: string;
}

export default function Chats() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  const [chats, setChats] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadChats = async () => {
      try {
        setLoading(true);
        setError('');

        // Check if we have an active session
        if (!telegramService.isClientConnected()) {
          console.log('No active session found, redirecting to auth');
          navigate('/');
          return;
        }

        // Validate the session is still active on the server
        const isValid = await telegramService.isSessionValid();
        if (!isValid) {
          console.log('Session is invalid on server, redirecting to auth');
          navigate('/');
          return;
        }

        console.log('Loading chats with active session...');

        // Получаем данные диалогов напрямую с сервера
        const serverChats = await telegramService.getDialogs();

        // Сортируем диалоги: сначала закрепленные, потом по времени
        const sortedChats = serverChats.sort((a, b) => {
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
          // Если оба закреплены или не закреплены, сортируем по времени (новые сначала)
          return 0; // Сервер уже отправляет отсортированные
        });

        // Преобразуем в форм��т для отображения
        const displayChats = sortedChats.map(chat => ({
          id: chat.id,
          name: chat.name,
          lastMessage: chat.lastMessage || '',
          time: chat.time || '',
          unreadCount: chat.unreadCount || 0,
          isOnline: chat.isOnline || false,
          isPinned: chat.isPinned || false,
          isGroup: chat.isGroup || false,
          lastMessageSender: chat.lastMessageSender,
          avatar: chat.avatar
        }));

        console.log('Chats loaded successfully:', displayChats.length, 'chats');
        setChats(displayChats);
      } catch (error: any) {
        console.error('Failed to load chats:', error);

        // If session error, redirect to auth
        if (error.message.includes('No active session') ||
            error.message.includes('Session not found') ||
            error.message.includes('Session expired') ||
            error.message.includes('not authenticated')) {
          console.log('Session expired, redirecting to auth');
          navigate('/');
          return;
        }

        setError(error.message || 'Failed to load chats');
      } finally {
        setLoading(false);
      }
    };

    loadChats();
  }, [navigate]);

  const filteredChats = chats.filter(chat =>
    chat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const handleLogout = async () => {
    try {
      await telegramService.disconnect();
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
      // Force redirect even if disconnect fails
      navigate('/');
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  const getAvatarColor = (name: string) => {
    const colors = [
      'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500',
      'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500'
    ];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <div className="h-screen bg-telegram-bg flex">
      {/* Sidebar */}
      <div className="w-96 bg-telegram-sidebar border-r border-border flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <Menu className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuItem>
                  <Bookmark className="mr-2 h-4 w-4" />
                  Saved Messages
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Users className="mr-2 h-4 w-4" />
                  Contacts
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Phone className="mr-2 h-4 w-4" />
                  Calls
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Archive className="mr-2 h-4 w-4" />
                  Archived Chats
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={toggleDarkMode}>
                  {darkMode ? (
                    <Sun className="mr-2 h-4 w-4" />
                  ) : (
                    <Moon className="mr-2 h-4 w-4" />
                  )}
                  {darkMode ? 'Light Mode' : 'Dark Mode'}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <h1 className="text-xl font-semibold">Telegram</h1>

            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Edit3 className="h-4 w-4" />
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background/50"
            />
          </div>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto">
          {error && (
            <div className="p-4 m-4 bg-destructive/10 border border-destructive/20 rounded-lg">
              <p className="text-destructive text-sm">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="p-8 text-center text-muted-foreground">
              <div className="h-12 w-12 mx-auto mb-4 border-4 border-primary border-t-transparent rounded-full animate-spin" />
              <p>Loading chats...</p>
            </div>
          ) : filteredChats.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No chats found</p>
            </div>
          ) : (
            filteredChats.map((chat) => (
              <Link
                key={chat.id}
                to={`/chat/${chat.id}`}
                className="block hover:bg-accent/50 transition-colors"
              >
                <div className="p-4 border-b border-border/30">
                  <div className="flex items-start space-x-3">
                    <div className="relative">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className={`${getAvatarColor(chat.name)} text-white`}>
                          {getInitials(chat.name)}
                        </AvatarFallback>
                        {chat.avatar?.hasPhoto && (
                          <AvatarImage
                            src={`/api/telegram/avatar/${chat.avatar.photoId}`}
                            alt={chat.name}
                            onError={(e) => {
                              // Hide image on error, show initials instead
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                        )}
                      </Avatar>
                      {chat.isOnline && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-telegram-online border-2 border-background rounded-full" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-medium text-foreground truncate">
                          {chat.name}
                        </h3>
                        <span className="text-xs text-muted-foreground flex-shrink-0">
                          {chat.time}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <p className="text-sm text-muted-foreground truncate">
                          {chat.isGroup && chat.lastMessageSender && (
                            <span className="text-primary">{chat.lastMessageSender}: </span>
                          )}
                          {chat.lastMessage}
                        </p>

                        <div className="flex items-center space-x-2 flex-shrink-0 ml-2">
                          {chat.isPinned && (
                            <div className="w-1 h-4 bg-primary rounded-full" title="Pinned" />
                          )}
                          {chat.unreadCount > 0 && (
                            <Badge
                              variant="default"
                              className="bg-primary text-primary-foreground min-w-[20px] h-5 text-xs rounded-full px-1.5"
                            >
                              {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex items-center justify-center bg-telegram-chat-bg">
        <div className="text-center space-y-4 max-w-md">
          <div className="w-32 h-32 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
            <svg width="64" height="64" viewBox="0 0 24 24" className="text-primary fill-current">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.16 1.84-.78 6.4-1.1 8.48-.14.88-.42 1.18-.68 1.21-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
            </svg>
          </div>
          <div>
            <h2 className="text-2xl font-semibold text-foreground mb-2">
              Select a chat to start messaging
            </h2>
            <p className="text-muted-foreground">
              Choose a conversation from the sidebar to view messages and start chatting.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
