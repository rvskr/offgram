import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, ExternalLink, Key, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CredentialsSetup() {
  return (
    <div className="min-h-screen bg-telegram-bg flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="w-20 h-20 mx-auto bg-destructive rounded-full flex items-center justify-center">
            <Key className="h-10 w-10 text-destructive-foreground" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">API Credentials Required</h1>
            <p className="text-telegram-text-secondary mt-2">
              This application requires valid Telegram API credentials to function.
            </p>
          </div>
        </div>

        {/* Main Card */}
        <Card className="border-border/50 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5" />
              <span>Setup Required</span>
            </CardTitle>
            <CardDescription>
              Follow these steps to configure Telegram API credentials for this application.
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Important:</strong> This app uses only real Telegram API integration. 
                No demo or mock modes are available.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Step 1: Get API Credentials</h3>
              <ol className="list-decimal list-inside space-y-2 text-sm">
                <li>Visit <strong>my.telegram.org</strong></li>
                <li>Log in with your Telegram phone number</li>
                <li>Click "API development tools"</li>
                <li>Create a new application:
                  <ul className="list-disc list-inside ml-4 mt-1 space-y-1">
                    <li><strong>App title:</strong> "Telegram Clone App"</li>
                    <li><strong>Short name:</strong> "tg-clone"</li>
                    <li><strong>Platform:</strong> Web</li>
                  </ul>
                </li>
                <li>Copy your <strong>API ID</strong> and <strong>API Hash</strong></li>
              </ol>

              <Button 
                variant="outline" 
                className="w-full" 
                onClick={() => window.open('https://my.telegram.org/apps', '_blank')}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Open my.telegram.org
              </Button>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Step 2: Configure Environment Variables</h3>
              <p className="text-sm text-muted-foreground">
                Set the following environment variables using the DevServerControl tool:
              </p>
              
              <div className="bg-muted p-4 rounded-md font-mono text-sm">
                <div>TELEGRAM_API_ID=your_api_id_here</div>
                <div>TELEGRAM_API_HASH=your_api_hash_here</div>
              </div>

              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  After setting the credentials, you must restart the development server for changes to take effect.
                </AlertDescription>
              </Alert>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Step 3: Restart & Test</h3>
              <p className="text-sm text-muted-foreground">
                Once credentials are configured:
              </p>
              <ul className="list-disc list-inside text-sm space-y-1">
                <li>Restart the development server</li>
                <li>Enter your phone number</li>
                <li>Receive real SMS verification code</li>
                <li>Access your actual Telegram chats</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            Need help? Check the{' '}
            <span className="text-primary font-medium">API_CREDENTIALS_SETUP.md</span>{' '}
            file for detailed instructions.
          </p>
        </div>
      </div>
    </div>
  );
}
