import Dexie, { Table } from 'dexie';

// Message types enum
export enum MessageType {
  Text = 'text',
  Photo = 'photo',
  Video = 'video',
  Audio = 'audio',
  Voice = 'voice',
  VideoNote = 'video_note', // кружки
  Document = 'document',
  Sticker = 'sticker',
  Location = 'location',
  Contact = 'contact',
  Poll = 'poll',
  WebPage = 'webpage',
  Game = 'game',
  Invoice = 'invoice',
  Unknown = 'unknown'
}

// Message status enum
export enum MessageStatus {
  Sending = 'sending',
  Sent = 'sent',
  Delivered = 'delivered',
  Read = 'read',
  Failed = 'failed'
}

// Media file interface
export interface MediaFile {
  id: string;
  messageId: string;
  type: 'photo' | 'video' | 'audio' | 'voice' | 'video_note' | 'document' | 'sticker';
  filename?: string;
  mimeType?: string;
  size: number;
  width?: number;
  height?: number;
  duration?: number; // для аудио/видео
  thumbnail?: string; // base64 превью
  localPath?: string; // путь к загруженному файлу
  downloadedAt?: Date;
  downloadUrl?: string;
}

// Message interface
export interface Message {
  id: string; // уникальный ID сообщения
  telegramId: number; // ID сообщения в Telegram
  chatId: string;
  fromId?: string;
  fromName?: string;
  type: MessageType;
  text?: string;
  media?: MediaFile[];
  replyToMessageId?: string;
  forwardFromChatId?: string;
  forwardFromMessageId?: string;
  date: Date;
  editDate?: Date;
  isOwn: boolean;
  status: MessageStatus;
  isDeleted: boolean;
  isEdited: boolean;
  deletedAt?: Date;
  views?: number;
  reactions?: MessageReaction[];
  createdAt: Date;
  updatedAt: Date;
}

// Message edit history
export interface MessageEdit {
  id: string;
  messageId: string;
  previousText?: string;
  previousMedia?: MediaFile[];
  editDate: Date;
  editReason?: string;
}

// Message reactions
export interface MessageReaction {
  id: string;
  messageId: string;
  emoji: string;
  count: number;
  isOwn: boolean;
}

// Chat interface
export interface Chat {
  id: string;
  telegramId: string;
  name: string;
  type: 'private' | 'group' | 'supergroup' | 'channel';
  avatar?: string;
  description?: string;
  membersCount?: number;
  isOnline?: boolean;
  lastSeenAt?: Date;
  lastMessageId?: string;
  lastMessageDate?: Date;
  unreadCount: number;
  isPinned: boolean;
  isMuted: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Contact interface
export interface Contact {
  id: string;
  telegramId: string;
  firstName: string;
  lastName?: string;
  username?: string;
  phoneNumber?: string;
  avatar?: string;
  isBot: boolean;
  isContact: boolean;
  isBlocked: boolean;
  lastSeenAt?: Date;
  isOnline: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Database class
export class TelegramDatabase extends Dexie {
  messages!: Table<Message>;
  messageEdits!: Table<MessageEdit>;
  messageReactions!: Table<MessageReaction>;
  mediaFiles!: Table<MediaFile>;
  chats!: Table<Chat>;
  contacts!: Table<Contact>;

  constructor() {
    super('TelegramDatabase');

    this.version(1).stores({
      messages: 'id, telegramId, chatId, fromId, type, date, isOwn, isDeleted, isEdited, createdAt, updatedAt',
      messageEdits: 'id, messageId, editDate',
      messageReactions: 'id, messageId, emoji, isOwn',
      mediaFiles: 'id, messageId, type, filename, size, downloadedAt',
      chats: 'id, telegramId, name, type, lastMessageDate, isPinned, unreadCount, updatedAt',
      contacts: 'id, telegramId, firstName, username, phoneNumber, isBot, isContact, isOnline, updatedAt'
    });

    // Hooks for automatic timestamps
    this.messages.hook('creating', (primKey, obj, trans) => {
      obj.createdAt = new Date();
      obj.updatedAt = new Date();
    });

    this.messages.hook('updating', (modifications, primKey, obj, trans) => {
      modifications.updatedAt = new Date();
    });

    this.chats.hook('creating', (primKey, obj, trans) => {
      obj.createdAt = new Date();
      obj.updatedAt = new Date();
    });

    this.chats.hook('updating', (modifications, primKey, obj, trans) => {
      modifications.updatedAt = new Date();
    });

    this.contacts.hook('creating', (primKey, obj, trans) => {
      obj.createdAt = new Date();
      obj.updatedAt = new Date();
    });

    this.contacts.hook('updating', (modifications, primKey, obj, trans) => {
      modifications.updatedAt = new Date();
    });
  }

  // Utility methods for messages
  async getMessagesForChat(chatId: string, limit = 50, offset = 0): Promise<Message[]> {
    return await this.messages
      .where('chatId')
      .equals(chatId)
      .reverse()
      .sortBy('date')
      .then(messages => messages.slice(offset, offset + limit));
  }

  async addMessage(message: Omit<Message, 'id' | 'createdAt' | 'updatedAt'>): Promise<string> {
    const id = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    await this.messages.add({ ...message, id });
    return id;
  }

  async updateMessage(messageId: string, updates: Partial<Message>): Promise<void> {
    await this.messages.update(messageId, updates);
  }

  async deleteMessage(messageId: string, soft = true): Promise<void> {
    if (soft) {
      await this.messages.update(messageId, {
        isDeleted: true,
        deletedAt: new Date()
      });
    } else {
      await this.messages.delete(messageId);
      await this.mediaFiles.where('messageId').equals(messageId).delete();
      await this.messageEdits.where('messageId').equals(messageId).delete();
      await this.messageReactions.where('messageId').equals(messageId).delete();
    }
  }

  async editMessage(messageId: string, newText: string, newMedia?: MediaFile[]): Promise<void> {
    const message = await this.messages.get(messageId);
    if (message) {
      // Сохраняем историю изменений
      const editId = `edit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await this.messageEdits.add({
        id: editId,
        messageId,
        previousText: message.text,
        previousMedia: message.media,
        editDate: new Date()
      });

      // Обновляем сообщение
      await this.messages.update(messageId, {
        text: newText,
        media: newMedia,
        isEdited: true,
        editDate: new Date()
      });
    }
  }

  async getMessageEditHistory(messageId: string): Promise<MessageEdit[]> {
    return await this.messageEdits
      .where('messageId')
      .equals(messageId)
      .sortBy('editDate');
  }

  // Utility methods for chats
  async getChats(): Promise<Chat[]> {
    return await this.chats
      .orderBy('lastMessageDate')
      .reverse()
      .toArray();
  }

  async addOrUpdateChat(chat: Omit<Chat, 'createdAt' | 'updatedAt'>): Promise<void> {
    const existing = await this.chats.get(chat.id);
    if (existing) {
      await this.chats.update(chat.id, chat);
    } else {
      await this.chats.add(chat as Chat);
    }
  }

  // Utility methods for media files
  async addMediaFile(mediaFile: MediaFile): Promise<void> {
    await this.mediaFiles.add(mediaFile);
  }

  async getMediaForMessage(messageId: string): Promise<MediaFile[]> {
    return await this.mediaFiles
      .where('messageId')
      .equals(messageId)
      .toArray();
  }

  // Utility methods for contacts
  async addOrUpdateContact(contact: Omit<Contact, 'createdAt' | 'updatedAt'>): Promise<void> {
    const existing = await this.contacts.get(contact.id);
    if (existing) {
      await this.contacts.update(contact.id, contact);
    } else {
      await this.contacts.add(contact as Contact);
    }
  }

  async getContacts(): Promise<Contact[]> {
    return await this.contacts
      .orderBy('firstName')
      .toArray();
  }

  // Search methods
  async searchMessages(query: string, chatId?: string): Promise<Message[]> {
    let collection = this.messages.toCollection();
    
    if (chatId) {
      collection = this.messages.where('chatId').equals(chatId);
    }

    return await collection
      .filter(message => 
        message.text?.toLowerCase().includes(query.toLowerCase()) ||
        message.fromName?.toLowerCase().includes(query.toLowerCase())
      )
      .reverse()
      .sortBy('date');
  }

  // Cleanup methods
  async clearOldMessages(daysOld = 30): Promise<void> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);

    await this.messages
      .where('date')
      .below(cutoffDate)
      .delete();
  }

  async clearAllData(): Promise<void> {
    await this.transaction('rw', this.messages, this.messageEdits, this.messageReactions, this.mediaFiles, this.chats, this.contacts, async () => {
      await this.messages.clear();
      await this.messageEdits.clear();
      await this.messageReactions.clear();
      await this.mediaFiles.clear();
      await this.chats.clear();
      await this.contacts.clear();
    });
  }
}

// Singleton instance
export const db = new TelegramDatabase();

// Initialize database
export const initDatabase = async (): Promise<void> => {
  try {
    await db.open();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};
