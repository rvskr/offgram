import { db, Message, MessageType, MessageStatus, Chat, Contact } from './database';
import { telegramService } from './telegram';

interface SyncOptions {
  forceRefresh?: boolean;
  chatId?: string;
  limit?: number;
}

export class MessageSyncService {
  private syncInProgress: Set<string> = new Set();
  private lastSyncTime: Map<string, Date> = new Map();

  async initializeDatabase(): Promise<void> {
    try {
      await db.open();
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async syncChats(options: SyncOptions = {}): Promise<Chat[]> {
    try {
      console.log('Syncing chats...');
      
      // Получаем диалоги с сервера
      const serverChats = await telegramService.getDialogs();
      
      // Обновляем локальную базу данных
      for (const serverChat of serverChats) {
        const chat: Chat = {
          id: serverChat.id,
          telegramId: serverChat.id,
          name: serverChat.name,
          type: serverChat.isGroup ? 'group' : 'private',
          avatar: serverChat.avatar,
          lastMessageDate: new Date(),
          unreadCount: serverChat.unreadCount || 0,
          isPinned: serverChat.isPinned || false,
          isMuted: false
        };

        await db.addOrUpdateChat(chat);
      }

      // Возвращаем актуальный список чатов из локальной БД
      return await db.getChats();
    } catch (error: any) {
      console.error('Failed to sync chats:', error);

      // If session expired, don't return cached data, let the error propagate
      if (error.message.includes('Session expired') ||
          error.message.includes('not authenticated') ||
          error.message.includes('Session not found')) {
        throw error;
      }

      // Возвращаем данные из локальной БД в случае других ошибок
      const localChats = await db.getChats();
      if (localChats.length > 0) {
        console.log('Returning cached chats');
        return localChats;
      }

      throw error;
    }
  }

  async syncMessages(chatId: string, options: SyncOptions = {}): Promise<Message[]> {
    const syncKey = `messages_${chatId}`;

    if (this.syncInProgress.has(syncKey)) {
      console.log('Sync already in progress for chat:', chatId);
      return await db.getMessagesForChat(chatId, options.limit);
    }

    this.syncInProgress.add(syncKey);

    try {
      console.log('Syncing messages for chat:', chatId);

      // Получаем сообщения с сервера
      const serverMessages = await telegramService.getMessages(chatId, options.limit || 50);

      // Обрабатываем каждое сообщение без очистки БД
      for (const serverMessage of serverMessages) {
        await this.processServerMessage(serverMessage, chatId);
      }

      // Обновляем время последней синхронизации
      this.lastSyncTime.set(chatId, new Date());

      // Возвращаем актуальные сообщения из локальной БД
      return await db.getMessagesForChat(chatId, options.limit);
    } catch (error) {
      console.error('Failed to sync messages:', error);

      // Возвращаем кэшированные сообщения в случае ошибки
      const localMessages = await db.getMessagesForChat(chatId, options.limit);
      if (localMessages.length > 0) {
        console.log('Returning cached messages');
        return localMessages;
      }

      throw error;
    } finally {
      this.syncInProgress.delete(syncKey);
    }
  }

  async syncNewMessages(chatId: string, limit = 10): Promise<Message[]> {
    const syncKey = `new_messages_${chatId}`;

    if (this.syncInProgress.has(syncKey)) {
      console.log('Sync new messages already in progress for chat:', chatId);
      return [];
    }

    this.syncInProgress.add(syncKey);

    try {
      console.log('Syncing new messages for chat:', chatId);

      // Получаем самое последнее сообщение из локальной БД
      const lastLocalMessage = await db.messages
        .where('chatId')
        .equals(chatId)
        .reverse()
        .sortBy('date')
        .then(messages => messages[0]);

      // Получаем новые сообщения с сервера
      const serverMessages = await telegramService.getMessages(chatId, limit);

      const newMessages: Message[] = [];

      // Обрабатываем только новые сообщения
      for (const serverMessage of serverMessages) {
        if (!lastLocalMessage || serverMessage.date > lastLocalMessage.date) {
          await this.processServerMessage(serverMessage, chatId);
          const message = await db.messages
            .where('telegramId')
            .equals(serverMessage.telegramId)
            .and(msg => msg.chatId === chatId)
            .first();
          if (message) {
            newMessages.push(message);
          }
        }
      }

      return newMessages;
    } catch (error) {
      console.error('Failed to sync new messages:', error);
      return [];
    } finally {
      this.syncInProgress.delete(syncKey);
    }
  }

  async loadOlderMessages(chatId: string, offsetDate: Date, limit = 20): Promise<Message[]> {
    const syncKey = `older_messages_${chatId}`;

    console.log('messageSyncService.loadOlderMessages called:', { chatId, offsetDate, limit });

    if (this.syncInProgress.has(syncKey)) {
      console.log('Load older messages already in progress for chat:', chatId);
      return [];
    }

    this.syncInProgress.add(syncKey);

    try {
      // Ensure offsetDate is a proper Date object
      const dateObj = offsetDate instanceof Date ? offsetDate : new Date(offsetDate);
      if (isNaN(dateObj.getTime())) {
        console.error('Invalid offsetDate provided:', offsetDate);
        return [];
      }

      console.log('Loading older messages for chat:', chatId, 'before:', dateObj);

      // Сначала попробуем найти ID самого старого сообщения в локальной БД
      const oldestLocal = await db.messages
        .where('chatId')
        .equals(chatId)
        .and(msg => msg.date < dateObj)
        .reverse()
        .sortBy('date')
        .then(messages => messages[0]);

      let serverMessages;
      if (oldestLocal && oldestLocal.telegramId) {
        // Используем ID для более надежной пагинации
        console.log('Using message ID approach with telegramId:', oldestLocal.telegramId);
        serverMessages = await telegramService.getMessagesBeforeId(chatId, oldestLocal.telegramId, limit);
      } else {
        // Fallback на дату
        console.log('Calling telegramService.getMessagesBeforeDate...');
        serverMessages = await telegramService.getMessagesBeforeDate(chatId, dateObj, limit);
      }
      console.log('Received server messages:', serverMessages.length);

      if (serverMessages.length === 0) {
        console.log('No server messages received - trying cached messages');

        // If no server messages, try to return cached messages before this date
        const cachedMessages = await db.messages
          .where('chatId')
          .equals(chatId)
          .and(msg => msg.date < dateObj)
          .reverse()
          .sortBy('date')
          .then(messages => messages.slice(0, limit));

        return cachedMessages;
      }

      // Обрабатываем каждое сообщение
      for (const serverMessage of serverMessages) {
        await this.processServerMessage(serverMessage, chatId);
      }

      // Возвращаем загруженные сообщения
      const olderMessages = await db.messages
        .where('chatId')
        .equals(chatId)
        .and(msg => msg.date < dateObj)
        .reverse()
        .sortBy('date')
        .then(messages => messages.slice(0, limit));

      return olderMessages;
    } catch (error) {
      console.error('Failed to load older messages:', error);
      return [];
    } finally {
      this.syncInProgress.delete(syncKey);
    }
  }

  private async processServerMessage(serverMessage: any, chatId: string): Promise<void> {
    const messageId = `${chatId}_${serverMessage.telegramId}`;

    // Проверяем, существует ли сообщение в локальной БД
    const existingMessage = await db.messages.where('telegramId').equals(serverMessage.telegramId).and(msg => msg.chatId === chatId).first();
    
    if (existingMessage) {
      // Проверяем, было ли сообщение изменено
      if (serverMessage.isEdited && serverMessage.editDate && 
          (!existingMessage.editDate || serverMessage.editDate > existingMessage.editDate)) {
        
        // Сохраняем историю изменений
        await this.saveEditHistory(existingMessage, serverMessage);
        
        // Обновляем сообщение
        await db.updateMessage(existingMessage.id, {
          text: serverMessage.text,
          media: this.convertServerMedia(serverMessage.media),
          isEdited: true,
          editDate: serverMessage.editDate
        });
      }
      
      // Проверяем, было ли сообщение удалено
      if (serverMessage.isDeleted && !existingMessage.isDeleted) {
        await db.updateMessage(existingMessage.id, {
          isDeleted: true,
          deletedAt: new Date()
        });
      }
    } else {
      // Создаем новое сообщение
      const message: Omit<Message, 'id' | 'createdAt' | 'updatedAt'> = {
        telegramId: serverMessage.telegramId,
        chatId,
        fromId: serverMessage.fromId,
        fromName: serverMessage.fromName,
        type: this.convertMessageType(serverMessage.type),
        text: serverMessage.text,
        media: this.convertServerMedia(serverMessage.media),
        replyToMessageId: serverMessage.replyToMsgId,
        forwardFromChatId: serverMessage.forwardedFrom?.fromId,
        forwardFromMessageId: serverMessage.forwardedFrom?.messageId,
        date: serverMessage.date,
        editDate: serverMessage.editDate,
        isOwn: serverMessage.isOwn,
        status: this.convertMessageStatus(serverMessage),
        isDeleted: serverMessage.isDeleted || false,
        isEdited: serverMessage.isEdited || false,
        deletedAt: serverMessage.deletedAt,
        views: serverMessage.views,
        reactions: []
      };

      console.log('Processing message:', {
        id: serverMessage.telegramId,
        text: serverMessage.text?.substring(0, 20),
        serverIsOwn: serverMessage.isOwn,
        messageIsOwn: message.isOwn
      });

      await db.addMessage(message);
    }
  }

  private async saveEditHistory(existingMessage: Message, serverMessage: any): Promise<void> {
    const editHistory = await db.getMessageEditHistory(existingMessage.id);
    
    // Если это первое изменение, сохраняем оригинальный текст
    if (editHistory.length === 0) {
      await db.messageEdits.add({
        id: `edit_${Date.now()}_original`,
        messageId: existingMessage.id,
        previousText: existingMessage.text,
        previousMedia: existingMessage.media,
        editDate: existingMessage.date
      });
    }

    // Сохраняем текущее состояние как предыдущую версию
    await db.messageEdits.add({
      id: `edit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      messageId: existingMessage.id,
      previousText: existingMessage.text,
      previousMedia: existingMessage.media,
      editDate: serverMessage.editDate
    });
  }

  private convertMessageType(serverType: string): MessageType {
    const typeMap: Record<string, MessageType> = {
      'text': MessageType.Text,
      'photo': MessageType.Photo,
      'video': MessageType.Video,
      'audio': MessageType.Audio,
      'voice': MessageType.Voice,
      'video_note': MessageType.VideoNote,
      'document': MessageType.Document,
      'sticker': MessageType.Sticker,
      'location': MessageType.Location,
      'contact': MessageType.Contact,
      'poll': MessageType.Poll,
      'webpage': MessageType.WebPage,
      'game': MessageType.Game,
      'invoice': MessageType.Invoice
    };

    return typeMap[serverType] || MessageType.Unknown;
  }

  private convertMessageStatus(serverMessage: any): MessageStatus {
    if (serverMessage.isOwn) {
      if (serverMessage.isRead) return MessageStatus.Read;
      if (serverMessage.isDelivered) return MessageStatus.Delivered;
      return MessageStatus.Sent;
    }
    return MessageStatus.Read;
  }

  private convertServerMedia(serverMedia: any[]): any[] {
    if (!serverMedia || !Array.isArray(serverMedia)) return [];
    
    return serverMedia.map(media => ({
      id: media.id,
      messageId: '', // будет установлено при сохранении
      type: media.type,
      filename: media.filename,
      mimeType: media.mimeType,
      size: media.size,
      width: media.width,
      height: media.height,
      duration: media.duration,
      thumbnail: media.thumbnail,
      localPath: media.localPath,
      downloadUrl: media.downloadUrl
    }));
  }

  async downloadAndCacheMedia(messageId: string, mediaIndex: number): Promise<string | null> {
    try {
      // Получаем медиафайл из базы данных
      const mediaFiles = await db.getMediaForMessage(messageId);
      const media = mediaFiles[mediaIndex];
      
      if (!media) {
        console.error('Media not found:', messageId, mediaIndex);
        return null;
      }

      // Проверяем, не загружен ли файл уже
      if (media.localPath) {
        return media.localPath;
      }

      // Загружаем файл с сервера
      const sessionId = localStorage.getItem('telegram_session_id');
      if (!sessionId) {
        throw new Error('No active session');
      }

      const response = await fetch(`/api/telegram/download-media?sessionId=${sessionId}&messageId=${messageId}&mediaIndex=${mediaIndex}`);
      
      if (!response.ok) {
        throw new Error(`Download failed: ${response.statusText}`);
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);

      // Обновляем запись в базе данных
      await db.mediaFiles.update(media.id, {
        localPath: url,
        downloadedAt: new Date()
      });

      return url;
    } catch (error) {
      console.error('Failed to download media:', error);
      return null;
    }
  }

  async searchMessages(query: string, chatId?: string): Promise<Message[]> {
    return await db.searchMessages(query, chatId);
  }

  async getMessageEditHistory(messageId: string) {
    return await db.getMessageEditHistory(messageId);
  }

  async clearCache(daysOld: number = 30): Promise<void> {
    await db.clearOldMessages(daysOld);
  }

  async clearAllData(): Promise<void> {
    await db.clearAllData();
    this.lastSyncTime.clear();
  }

  // Автоматическая синхронизация
  startAutoSync(intervalMs: number = 30000): void {
    setInterval(async () => {
      try {
        // Синхронизируем только если есть активная сессия
        if (telegramService.isClientConnected()) {
          await this.syncChats();
        }
      } catch (error) {
        console.error('Auto-sync failed:', error);
      }
    }, intervalMs);
  }

  getLastSyncTime(chatId: string): Date | null {
    return this.lastSyncTime.get(chatId) || null;
  }
}

// Singleton instance
export const messageSyncService = new MessageSyncService();
