class TelegramService {
  private sessionId: string | null = null;
  private phoneNumber = '';

  constructor() {
    // No direct client needed - using API endpoints
    // Restore session from localStorage if available
    this.sessionId = localStorage.getItem('telegram_session_id');
    this.phoneNumber = localStorage.getItem('telegram_phone_number') || '';
  }

  async connect(): Promise<void> {
    // Connection is handled server-side
    console.log('Telegram service ready (server-side connection)');
  }

  async validateSession(): Promise<boolean> {
    if (!this.sessionId) {
      return false;
    }

    try {
      // Make a lightweight call to validate the session
      const response = await fetch(`/api/telegram/dialogs?sessionId=${this.sessionId}&limit=1`);
      if (response.status === 401 || response.status === 403) {
        console.log('Session is invalid, clearing local session');
        this.sessionId = null;
        this.phoneNumber = '';
        localStorage.removeItem('telegram_session_id');
        localStorage.removeItem('telegram_phone_number');
        return false;
      }

      return response.ok;
    } catch (error) {
      console.error('Session validation failed:', error);
      return false;
    }
  }

  private async handleResponse(response: Response) {
    let text: string = '';
    let data: any = {};

    // Check if we can read the body safely
    if (!response.bodyUsed) {
      try {
        // Clone before reading to preserve original response
        const clonedResponse = response.clone();
        text = await clonedResponse.text();
        console.log(`Response status: ${response.status}, body: ${text}`);
      } catch (e) {
        console.warn('Failed to read cloned response:', e);
        try {
          // Fallback: try reading the original response if clone failed
          text = await response.text();
        } catch (e2) {
          console.warn('Failed to read original response:', e2);
        }
      }
    } else {
      console.warn('Response body already consumed, cannot read error details');
    }

    // Try to parse as JSON, fallback to plain text
    if (text) {
      try {
        data = JSON.parse(text);
      } catch (e) {
        // If not JSON, treat as plain text
        data = { message: text };
      }
    }

    if (!response.ok) {
      // Extract error message from server response
      let errorMessage = data.error || data.message || text;

      // Fallback to status text if no message found
      if (!errorMessage || errorMessage.trim() === '') {
        errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      }

      console.log(`Error extracted: ${errorMessage}`);

      const error = new Error(errorMessage);
      (error as any).status = response.status;
      throw error;
    }

    return data;
  }

  async sendCode(phoneNumber: string): Promise<{ phoneCodeHash: string }> {
    try {
      this.phoneNumber = phoneNumber;

      console.log(`Sending code to ${phoneNumber}...`);
      const response = await fetch('/api/telegram/send-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ phone: phoneNumber }),
      });

      console.log(`Response received: ${response.status} ${response.statusText}`);
      const result = await this.handleResponse(response);
      
      // Handle successful response
      if (result.sessionId && result.phoneCodeHash) {
        this.sessionId = result.sessionId;
        localStorage.setItem('telegram_session_id', result.sessionId);
        localStorage.setItem('telegram_phone_number', phoneNumber);

        // If session was restored, no need for code verification
        if (result.restored) {
          console.log('Session restored successfully');
          return {
            phoneCodeHash: result.phoneCodeHash,
            restored: true
          };
        }

        return {
          phoneCodeHash: result.phoneCodeHash,
        };
      }

      // Fallback for successful response without expected data
      if (response.ok) {
        this.sessionId = `session_${phoneNumber.replace(/[^0-9]/g, '')}_${Date.now()}`;
        return {
          phoneCodeHash: `hash_${Date.now()}`,
        };
      }

      throw new Error('Unexpected response format');
    } catch (error: any) {
      console.error('Failed to send code:', error);
      throw new Error(error.message || 'Failed to send verification code');
    }
  }

  async signIn(code: string, phoneCodeHash: string): Promise<{ success: boolean; requires2FA?: boolean }> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      const response = await fetch('/api/telegram/sign-in', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionId: this.sessionId,
          phone: this.phoneNumber,
          code,
          phoneCodeHash,
        }),
      });

      const result = await this.handleResponse(response);
      return result;
    } catch (error: any) {
      console.error('Sign in failed:', error);
      throw new Error(error.message || 'Invalid verification code');
    }
  }

  async checkPassword(password: string): Promise<{ success: boolean }> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      console.log(`Checking 2FA password for session ${this.sessionId}...`);
      const response = await fetch('/api/telegram/check-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionId: this.sessionId,
          password,
        }),
      });

      console.log(`2FA Response received: ${response.status} ${response.statusText}`);
      const result = await this.handleResponse(response);
      return result;
    } catch (error: any) {
      console.error('2FA failed:', error);
      throw new Error(error.message || 'Invalid 2FA password');
    }
  }

  async getDialogs(): Promise<Array<{
    id: string;
    name: string;
    lastMessage: string;
    time: string;
    unreadCount: number;
    isOnline?: boolean;
    isPinned?: boolean;
    isGroup?: boolean;
    lastMessageSender?: string;
    avatar?: string;
  }>> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      console.log(`Loading dialogs for session: ${this.sessionId}`);
      const response = await fetch(`/api/telegram/dialogs?sessionId=${this.sessionId}`);
      console.log(`Dialogs response: ${response.status} ${response.statusText}`);
      const result = await this.handleResponse(response);
      console.log(`Dialogs loaded:`, result);
      return Array.isArray(result) ? result : [];
    } catch (error: any) {
      console.error('Failed to get dialogs:', error);

      // If session is invalid, clear it
      if (error.message.includes('Session not found') || error.message.includes('not authenticated') || error.status === 401) {
        console.log('Session expired or invalid, clearing local session');
        this.sessionId = null;
        this.phoneNumber = '';
        localStorage.removeItem('telegram_session_id');
        localStorage.removeItem('telegram_phone_number');
        throw new Error('Session expired. Please sign in again.');
      }

      throw new Error(error.message || 'Failed to load chats');
    }
  }

  async getMessages(chatId: string, limit = 50): Promise<Array<{
    id: string;
    text: string;
    time: string;
    isOwn: boolean;
    isRead?: boolean;
    isDelivered?: boolean;
  }>> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      const response = await fetch(`/api/telegram/messages?sessionId=${this.sessionId}&chatId=${chatId}&limit=${limit}`);
      const result = await this.handleResponse(response);
      return Array.isArray(result) ? result : [];
    } catch (error: any) {
      console.error('Failed to get messages:', error);

      // If session is invalid, clear it
      if (error.message.includes('Session not found') || error.message.includes('not authenticated') || error.status === 401) {
        console.log('Session expired or invalid, clearing local session');
        this.sessionId = null;
        this.phoneNumber = '';
        localStorage.removeItem('telegram_session_id');
        localStorage.removeItem('telegram_phone_number');
        throw new Error('Session expired. Please sign in again.');
      }

      throw new Error(error.message || 'Failed to load messages');
    }
  }

  async sendMessage(chatId: string, text: string): Promise<void> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      const response = await fetch('/api/telegram/send-message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionId: this.sessionId,
          chatId,
          text,
        }),
      });

      await this.handleResponse(response);
    } catch (error: any) {
      console.error('Failed to send message:', error);
      throw new Error(error.message || 'Failed to send message');
    }
  }

  async getMessagesBeforeDate(chatId: string, beforeDate: Date, limit = 20): Promise<Array<{
    id: string;
    text: string;
    time: string;
    isOwn: boolean;
    isRead?: boolean;
    isDelivered?: boolean;
  }>> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      // Ensure beforeDate is a proper Date object
      const dateObj = beforeDate instanceof Date ? beforeDate : new Date(beforeDate);
      if (isNaN(dateObj.getTime())) {
        throw new Error('Invalid date provided');
      }

      const response = await fetch(`/api/telegram/messages/older?sessionId=${this.sessionId}&chatId=${chatId}&beforeDate=${dateObj.toISOString()}&limit=${limit}`);
      const result = await this.handleResponse(response);
      return Array.isArray(result) ? result : [];
    } catch (error: any) {
      console.error('Failed to get older messages:', error);

      // If session is invalid, clear it
      if (error.message.includes('Session not found') || error.message.includes('not authenticated') || error.status === 401) {
        console.log('Session expired or invalid, clearing local session');
        this.sessionId = null;
        this.phoneNumber = '';
        localStorage.removeItem('telegram_session_id');
        localStorage.removeItem('telegram_phone_number');
        throw new Error('Session expired. Please sign in again.');
      }

      throw new Error(error.message || 'Failed to load older messages');
    }
  }

  async getMessagesBeforeId(chatId: string, messageId: number, limit = 20): Promise<Array<{
    id: string;
    text: string;
    time: string;
    isOwn: boolean;
    isRead?: boolean;
    isDelivered?: boolean;
  }>> {
    if (!this.sessionId) {
      throw new Error('No active session');
    }

    try {
      console.log(`Getting messages before ID ${messageId} for chat ${chatId}`);
      const response = await fetch(`/api/telegram/messages/older?sessionId=${this.sessionId}&chatId=${chatId}&lastMessageId=${messageId}&limit=${limit}`);
      const result = await this.handleResponse(response);
      console.log(`Received ${Array.isArray(result) ? result.length : 0} older messages`);
      return Array.isArray(result) ? result : [];
    } catch (error: any) {
      console.error('Failed to get older messages by ID:', error);

      // If session is invalid, clear it
      if (error.message.includes('Session not found') || error.message.includes('not authenticated') || error.status === 401) {
        console.log('Session expired or invalid, clearing local session');
        this.sessionId = null;
        this.phoneNumber = '';
        localStorage.removeItem('telegram_session_id');
        localStorage.removeItem('telegram_phone_number');
        throw new Error('Session expired. Please sign in again.');
      }

      throw new Error(error.message || 'Failed to load older messages');
    }
  }

  isClientConnected(): boolean {
    const connected = this.sessionId !== null;
    console.log(`isClientConnected: ${connected}, sessionId: ${this.sessionId}`);
    return connected;
  }

  async isSessionValid(): Promise<boolean> {
    if (!this.sessionId) {
      return false;
    }
    return await this.validateSession();
  }

  async disconnect(): Promise<void> {
    if (this.sessionId) {
      try {
        const response = await fetch('/api/telegram/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            sessionId: this.sessionId,
          }),
        });

        // Don't throw error on logout failure, just log it
        try {
          await this.handleResponse(response);
        } catch (error) {
          console.error('Logout API call failed, but continuing with local cleanup:', error);
        }
      } catch (error) {
        console.error('Error calling logout API:', error);
      }
    }

    this.sessionId = null;
    this.phoneNumber = '';

    // Clear localStorage
    localStorage.removeItem('telegram_session_id');
    localStorage.removeItem('telegram_phone_number');
  }
}

export const telegramService = new TelegramService();
