import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { sendCode, signIn, checkPassword, getDialogs, getMessages, sendMessage, downloadAvatar, downloadMedia, logout, getOlderMessages } from "./routes/telegram";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Telegram API routes
  app.post("/api/telegram/send-code", sendCode);
  app.post("/api/telegram/sign-in", signIn);
  app.post("/api/telegram/check-password", checkPassword);
  app.get("/api/telegram/dialogs", getDialogs);
  app.get("/api/telegram/messages", getMessages);
  app.get("/api/telegram/messages/older", getOlderMessages);
  app.post("/api/telegram/send-message", sendMessage);
  app.get("/api/telegram/avatar/:photoId", downloadAvatar);
  app.get("/api/telegram/download-media", downloadMedia);
  app.post("/api/telegram/logout", logout);

  return app;
}
