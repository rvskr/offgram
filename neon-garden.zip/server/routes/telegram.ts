import { RequestHandler } from "express";
import { telegramServerService } from "../services/telegram.js";

export const sendCode: RequestHandler = async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return res.status(400).json({ error: 'Phone number is required' });
    }

    console.log(`Attempting to send code to: ${phone}`);
    const result = await telegramServerService.sendCode(phone);
    console.log(`Code sent successfully to: ${phone}`);
    res.json(result);
  } catch (error: any) {
    console.error('Send code error:', error);

    // Handle specific error cases
    let errorMessage = 'Failed to send verification code';
    let statusCode = 500;

    if (error.message.includes('TELEGRAM_API_ID and TELEGRAM_API_HASH')) {
      errorMessage = 'API credentials not configured. Please set TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables.';
      statusCode = 503; // Service Unavailable
    } else if (error.message.includes('AUTH_RESTART') || error.message.includes('Authentication session was reset')) {
      errorMessage = 'Authentication session was reset. Please try again.';
      statusCode = 401; // Unauthorized - need to restart auth
    } else if (error.message.includes('API_ID_INVALID')) {
      errorMessage = 'Invalid API credentials. Please check your TELEGRAM_API_ID and TELEGRAM_API_HASH.';
      statusCode = 401; // Unauthorized
    } else if (error.message.includes('PHONE_NUMBER_INVALID')) {
      errorMessage = 'Invalid phone number format. Please use international format (+1234567890)';
      statusCode = 400; // Bad Request
    } else if (error.message.includes('FLOOD') || error.message.includes('wait') || error.message.includes('Too many requests')) {
      errorMessage = error.message; // Use the specific wait time message from the service
      statusCode = 429; // Too Many Requests
    } else if (error.message.includes('PHONE_NUMBER_BANNED')) {
      errorMessage = 'This phone number is banned from Telegram';
      statusCode = 403; // Forbidden
    } else if (error.message) {
      errorMessage = error.message;
    }

    res.status(statusCode).json({ error: errorMessage });
  }
};

export const signIn: RequestHandler = async (req, res) => {
  try {
    const { sessionId, phone, code, phoneCodeHash } = req.body;

    if (!sessionId || !phone || !code || !phoneCodeHash) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    console.log(`Attempting sign in for: ${phone} with code: ${code}`);
    const result = await telegramServerService.signIn(sessionId, phone, code, phoneCodeHash);

    if (result.success) {
      console.log(`Sign in successful for: ${phone}`);
    } else if (result.requires2FA) {
      console.log(`2FA required for: ${phone}`);
    }

    res.json(result);
  } catch (error: any) {
    console.error('Sign in error:', error);

    // Handle specific error cases
    let errorMessage = 'Sign in failed';
    let statusCode = 500;

    if (error.message.includes('TELEGRAM_API_ID and TELEGRAM_API_HASH')) {
      errorMessage = 'API credentials not configured. Please set TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables.';
      statusCode = 503; // Service Unavailable
    } else if (error.message.includes('Session not found')) {
      errorMessage = 'Session expired. Please start authentication again.';
      statusCode = 401; // Unauthorized
    } else if (error.message.includes('PHONE_CODE_INVALID')) {
      errorMessage = 'Invalid verification code. Please check and try again';
      statusCode = 400; // Bad Request
    } else if (error.message.includes('PHONE_CODE_EXPIRED')) {
      errorMessage = 'Verification code expired. Please request a new one';
      statusCode = 400; // Bad Request
    } else if (error.message.includes('SESSION_PASSWORD_NEEDED')) {
      return res.json({ success: false, requires2FA: true });
    } else if (error.message.includes('FLOOD_WAIT')) {
      errorMessage = 'Too many attempts. Please wait a few minutes before trying again.';
      statusCode = 429; // Too Many Requests
    } else if (error.message) {
      errorMessage = error.message;
    }

    res.status(statusCode).json({ error: errorMessage });
  }
};

export const checkPassword: RequestHandler = async (req, res) => {
  try {
    const { sessionId, password } = req.body;

    if (!sessionId || !password) {
      return res.status(400).json({ error: 'Session ID and password are required' });
    }

    const result = await telegramServerService.checkPassword(sessionId, password);
    res.json(result);
  } catch (error: any) {
    console.error('Check password error:', error);

    // Handle specific error cases
    let errorMessage = '2FA verification failed';
    let statusCode = 500;

    if (error.message.includes('TELEGRAM_API_ID and TELEGRAM_API_HASH')) {
      errorMessage = 'API credentials not configured. Please set TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables.';
      statusCode = 503; // Service Unavailable
    } else if (error.message.includes('Session not found')) {
      errorMessage = 'Session expired. Please start authentication again.';
      statusCode = 401; // Unauthorized
    } else if (error.message.includes('PASSWORD_HASH_INVALID')) {
      errorMessage = 'Invalid 2FA password. Please check your password and try again.';
      statusCode = 400; // Bad Request
    } else if (error.message.includes('FLOOD_WAIT')) {
      errorMessage = 'Too many attempts. Please wait a few minutes before trying again.';
      statusCode = 429; // Too Many Requests
    } else if (error.message) {
      errorMessage = error.message;
    }

    res.status(statusCode).json({ error: errorMessage });
  }
};

export const getDialogs: RequestHandler = async (req, res) => {
  try {
    const { sessionId } = req.query;
    
    if (!sessionId || typeof sessionId !== 'string') {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    const dialogs = await telegramServerService.getDialogs(sessionId);
    res.json(dialogs);
  } catch (error: any) {
    console.error('Get dialogs error:', error);
    res.status(500).json({ error: error.message || 'Failed to load chats' });
  }
};

export const getMessages: RequestHandler = async (req, res) => {
  try {
    const { sessionId, chatId, limit } = req.query;
    
    if (!sessionId || typeof sessionId !== 'string') {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    
    if (!chatId || typeof chatId !== 'string') {
      return res.status(400).json({ error: 'Chat ID is required' });
    }

    const messages = await telegramServerService.getMessages(
      sessionId, 
      chatId, 
      limit ? parseInt(limit as string) : 50
    );
    res.json(messages);
  } catch (error: any) {
    console.error('Get messages error:', error);
    res.status(500).json({ error: error.message || 'Failed to load messages' });
  }
};

export const sendMessage: RequestHandler = async (req, res) => {
  try {
    const { sessionId, chatId, text } = req.body;

    if (!sessionId || !chatId || !text) {
      return res.status(400).json({ error: 'Session ID, chat ID, and text are required' });
    }

    await telegramServerService.sendMessage(sessionId, chatId, text);
    res.json({ success: true });
  } catch (error: any) {
    console.error('Send message error:', error);
    res.status(500).json({ error: error.message || 'Failed to send message' });
  }
};

export const getOlderMessages: RequestHandler = async (req, res) => {
  try {
    const { sessionId, chatId, beforeDate, lastMessageId, limit } = req.query;

    if (!sessionId || typeof sessionId !== 'string') {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    if (!chatId || typeof chatId !== 'string') {
      return res.status(400).json({ error: 'Chat ID is required' });
    }

    // Support both date and messageId approaches
    let messages;
    if (lastMessageId && typeof lastMessageId === 'string') {
      // Use message ID approach (more reliable)
      messages = await telegramServerService.getMessagesBeforeId(
        sessionId,
        chatId,
        parseInt(lastMessageId),
        limit ? parseInt(limit as string) : 20
      );
    } else if (beforeDate && typeof beforeDate === 'string') {
      // Fallback to date approach
      const date = new Date(beforeDate);
      if (isNaN(date.getTime())) {
        return res.status(400).json({ error: 'Invalid date format' });
      }

      messages = await telegramServerService.getMessagesBeforeDate(
        sessionId,
        chatId,
        date,
        limit ? parseInt(limit as string) : 20
      );
    } else {
      return res.status(400).json({ error: 'Either beforeDate or lastMessageId is required' });
    }

    res.json(messages);
  } catch (error: any) {
    console.error('Get older messages error:', error);
    res.status(500).json({ error: error.message || 'Failed to load older messages' });
  }
};

export const downloadAvatar: RequestHandler = async (req, res) => {
  try {
    const { photoId } = req.params;
    const { sessionId } = req.query;

    if (!sessionId || typeof sessionId !== 'string') {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    if (!photoId) {
      return res.status(400).json({ error: 'Photo ID is required' });
    }

    try {
      // Пытаемся загрузить ав��тар
      const result = await telegramServerService.downloadAvatar(sessionId, photoId);

      if (result) {
        res.setHeader('Content-Type', result.mimeType || 'image/jpeg');
        res.setHeader('Cache-Control', 'public, max-age=86400'); // Кэшируем на 24 часа
        res.send(result.buffer);
      } else {
        res.status(404).json({ error: 'Avatar not found' });
      }
    } catch (error) {
      console.log('Avatar not available for photoId:', photoId);
      res.status(404).json({ error: 'Avatar not found' });
    }
  } catch (error: any) {
    console.error('Download avatar error:', error);
    res.status(500).json({ error: error.message || 'Failed to download avatar' });
  }
};

export const downloadMedia: RequestHandler = async (req, res) => {
  try {
    const { sessionId, messageId } = req.query;

    if (!sessionId || typeof sessionId !== 'string') {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    if (!messageId || typeof messageId !== 'string') {
      return res.status(400).json({ error: 'Message ID is required' });
    }

    const result = await telegramServerService.downloadMedia(sessionId, messageId);

    // Устанавливаем правильные заголовки для загрузки
    res.setHeader('Content-Type', result.mimeType);
    res.setHeader('Content-Disposition', `attachment; filename="${result.filename}"`);
    res.setHeader('Content-Length', result.buffer.length);

    res.send(result.buffer);
  } catch (error: any) {
    console.error('Download media error:', error);
    res.status(500).json({ error: error.message || 'Failed to download media' });
  }
};

export const logout: RequestHandler = async (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    await telegramServerService.logout(sessionId);
    res.json({ success: true });
  } catch (error: any) {
    console.error('Logout error:', error);
    res.status(500).json({ error: error.message || 'Logout failed' });
  }
};
