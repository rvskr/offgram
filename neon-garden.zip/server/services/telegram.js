import fs from 'fs';
import path from 'path';

// Real Telegram API integration only - no demo/mock mode
class TelegramServerService {
  constructor() {
    this.sessions = new Map();
    this.clients = new Map();
    // These will be checked when actually using Telegram API
    this.apiId = parseInt(process.env.TELEGRAM_API_ID);
    this.apiHash = process.env.TELEGRAM_API_HASH;
    this.telegramModules = null;
    this.sessionsDir = path.join(process.cwd(), '.sessions');

    // Create sessions directory if it doesn't exist
    this.ensureSessionsDir();

    // Load saved sessions on startup
    this.loadSavedSessions();
  }

  async cleanup() {
    console.log('Cleaning up all Telegram clients...');
    for (const [sessionId, client] of this.clients) {
      try {
        await client.disconnect();
        console.log(`Client ${sessionId} disconnected`);
      } catch (e) {
        console.warn(`Error disconnecting client ${sessionId}:`, e);
      }
    }
    this.clients.clear();
    this.sessions.clear();
  }

  checkCredentials() {
    if (!this.apiId || !this.apiHash) {
      throw new Error('TELEGRAM_API_ID and TELEGRAM_API_HASH environment variables are required. Get them from https://my.telegram.org/apps');
    }
  }

  async initTelegram() {
    if (!this.telegramModules) {
      const { TelegramClient } = await import('telegram');
      const { StringSession } = await import('telegram/sessions');
      const { Api } = await import('telegram/tl');
      
      this.telegramModules = {
        TelegramClient,
        StringSession,
        Api
      };
      
      console.log('Telegram modules loaded successfully');
    }
    return true;
  }

  getSessionId(phone) {
    return `session_${phone.replace(/[^0-9]/g, '')}`;
  }

  async createClient(phone, savedSessionString = '') {
    const sessionId = this.getSessionId(phone);

    // Clean up any existing client for this phone to avoid AUTH_RESTART
    if (this.clients.has(sessionId)) {
      console.log(`Cleaning up existing client for ${phone}`);
      const existingClient = this.clients.get(sessionId);
      try {
        await existingClient.disconnect();
      } catch (e) {
        console.warn('Error disconnecting existing client:', e);
      }
      this.clients.delete(sessionId);
      this.sessions.delete(sessionId);
    }

    // Check credentials only when actually needed
    this.checkCredentials();

    await this.initTelegram();

    const { TelegramClient, StringSession } = this.telegramModules;
    const session = new StringSession(savedSessionString);

    const client = new TelegramClient(session, this.apiId, this.apiHash, {
      connectionRetries: 5,
    });

    await client.connect();

    this.clients.set(sessionId, client);

    // If we have a saved session string, assume we're authenticated
    const isAuthenticated = savedSessionString !== '';
    this.sessions.set(sessionId, {
      phone,
      authenticated: isAuthenticated,
      sessionString: savedSessionString
    });

    console.log(`Telegram client created for ${phone}, authenticated: ${isAuthenticated}`);
    return sessionId;
  }

  async sendCode(phone) {
    const sessionId = this.getSessionId(phone);

    // Check if we have a saved session for this phone
    const savedSessionString = this.loadSessionFromFile(sessionId);
    if (savedSessionString) {
      console.log(`Found saved session for ${phone}, attempting to restore...`);
      try {
        await this.createClient(phone, savedSessionString);
        // If restore was successful, user is already authenticated
        return {
          phoneCodeHash: 'restored_session',
          sessionId,
          restored: true
        };
      } catch (error) {
        console.log(`Failed to restore session for ${phone}, will send new code:`, error);
        // Delete invalid session file
        this.deleteSessionFile(sessionId);
      }
    }

    // Create new client for fresh authentication
    await this.createClient(phone);
    const client = this.clients.get(sessionId);

    if (!client) {
      throw new Error('Client not found');
    }

    try {
      const { Api } = this.telegramModules;

      const result = await client.invoke(
        new Api.auth.SendCode({
          phoneNumber: phone,
          apiId: this.apiId,
          apiHash: this.apiHash,
          settings: new Api.CodeSettings({
            allowFlashcall: false,
            currentNumber: false,
            allowAppHash: false,
            allowMissedCall: false,
            allowFirebase: false,
          }),
        })
      );

      console.log(`SMS code sent to ${phone}`);
      return {
        phoneCodeHash: result.phoneCodeHash,
        sessionId,
      };
    } catch (error) {
      console.error('Failed to send code:', error);

      // Handle specific Telegram errors
      if (error.errorMessage === 'AUTH_RESTART') {
        // Clean up the client and try once more
        console.log('AUTH_RESTART error, cleaning up client and retrying...');
        this.clients.delete(sessionId);
        this.sessions.delete(sessionId);
        throw new Error('Authentication session was reset. Please try again.');
      } else if (error.errorMessage === 'PHONE_NUMBER_INVALID') {
        throw new Error('Invalid phone number format. Please use international format (+1234567890)');
      } else if (error.errorMessage === 'FLOOD' || error.code === 420 || error.errorMessage === 'FLOOD_WAIT') {
        const seconds = error.seconds || 60;
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);

        let waitMessage = `Too many requests. Please wait `;
        if (hours > 0) {
          waitMessage += `${hours} hour(s)`;
          if (minutes > 0) waitMessage += ` and ${minutes} minute(s)`;
        } else if (minutes > 0) {
          waitMessage += `${minutes} minute(s)`;
        } else {
          waitMessage += `${seconds} second(s)`;
        }
        waitMessage += ` before trying again.`;

        throw new Error(waitMessage);
      } else if (error.errorMessage === 'PHONE_NUMBER_BANNED') {
        throw new Error('This phone number is banned from Telegram');
      } else if (error.errorMessage === 'API_ID_INVALID' || error.errorMessage === 'API_ID_PUBLISHED_FLOOD') {
        throw new Error('Invalid API credentials. Please check your TELEGRAM_API_ID and TELEGRAM_API_HASH.');
      }

      throw new Error(`Failed to send verification code: ${error.message || error.errorMessage || 'Unknown error'}`);
    }
  }

  async signIn(sessionId, phone, code, phoneCodeHash) {
    const session = this.sessions.get(sessionId);
    const client = this.clients.get(sessionId);

    if (!session || !client) {
      throw new Error('Session or client not found');
    }

    try {
      const { Api } = this.telegramModules;

      const result = await client.invoke(
        new Api.auth.SignIn({
          phoneNumber: phone,
          phoneCodeHash,
          phoneCode: code,
        })
      );

      if (result.className === 'auth.Authorization') {
        session.authenticated = true;
        // Save session string for persistence
        session.sessionString = client.session.save();
        this.saveSessionToFile(sessionId, session.sessionString);
        console.log(`User ${phone} successfully authenticated`);
        return { success: true, sessionString: session.sessionString };
      } else if (result.className === 'auth.AuthorizationSignUpRequired') {
        throw new Error('Account registration required. Please register first in official Telegram app.');
      }

      return { success: false };
    } catch (error) {
      console.error('Sign in error:', error);

      // Handle specific Telegram errors
      if (error.errorMessage === 'SESSION_PASSWORD_NEEDED') {
        console.log(`2FA required for ${phone}`);
        return { success: false, requires2FA: true };
      } else if (error.errorMessage === 'PHONE_CODE_INVALID') {
        throw new Error('Invalid verification code. Please check and try again');
      } else if (error.errorMessage === 'PHONE_CODE_EXPIRED') {
        throw new Error('Verification code expired. Please request a new one');
      } else if (error.errorMessage === 'FLOOD_WAIT') {
        const seconds = error.seconds || 60;
        throw new Error(`Too many attempts. Please wait ${seconds} seconds before trying again.`);
      }

      throw error;
    }
  }

  async checkPassword(sessionId, password) {
    const session = this.sessions.get(sessionId);
    const client = this.clients.get(sessionId);

    if (!session || !client) {
      throw new Error('Session or client not found');
    }

    try {
      const { Api } = this.telegramModules;

      // Get password info for SRP computation
      const passwordInfo = await client.invoke(new Api.account.GetPassword());

      // Use the client's built-in method to compute SRP
      const checkPasswordSrp = await client.computeCheck(password, passwordInfo);

      // Invoke auth.checkPassword with computed SRP
      const result = await client.invoke(
        new Api.auth.CheckPassword({
          password: checkPasswordSrp,
        })
      );

      if (result.className === 'auth.Authorization') {
        session.authenticated = true;
        // Save session string for persistence
        session.sessionString = client.session.save();
        this.saveSessionToFile(sessionId, session.sessionString);
        console.log(`2FA authentication successful for session ${sessionId}`);
        return { success: true, sessionString: session.sessionString };
      }

      return { success: false };
    } catch (error) {
      console.error('2FA authentication failed:', error);

      // Handle specific Telegram errors
      if (error.errorMessage === 'PASSWORD_HASH_INVALID') {
        throw new Error('Invalid 2FA password. Please check your password and try again.');
      } else if (error.errorMessage === 'FLOOD_WAIT') {
        const seconds = error.seconds || 60;
        throw new Error(`Too many attempts. Please wait ${seconds} seconds before trying again.`);
      }

      throw new Error(`2FA verification failed: ${error.message}`);
    }
  }

  async getDialogs(sessionId) {
    const session = this.sessions.get(sessionId);
    let client = this.clients.get(sessionId);

    if (!session || !session.authenticated) {
      throw new Error('Session not found or not authenticated');
    }

    // Restore client if not active
    if (!client) {
      const restored = await this.restoreClient(sessionId);
      if (!restored) {
        throw new Error('Failed to restore session');
      }
      client = this.clients.get(sessionId);
    }

    const dialogs = await client.getDialogs({ limit: 50 });

    const dialogsData = dialogs.map((dialog) => {
      try {
        const entity = dialog.entity;
        const message = dialog.message;

        return {
          id: entity.id.toString(),
          name: this.getEntityName(entity),
          lastMessage: message?.message || '',
          time: this.formatMessageTime(message?.date),
          lastMessageDate: message?.date || 0,
          unreadCount: dialog.unreadCount || 0,
          isGroup: this.isGroup(entity),
          isPinned: dialog.pinned || false,
          isOnline: this.isOnline(entity),
          lastMessageSender: this.getLastMessageSender(message, entity),
          avatar: this.getEntityAvatar(entity),
        };
      } catch (error) {
        console.error('Error processing dialog:', error, dialog);
        // Return a safe fallback dialog
        return {
          id: dialog.entity?.id?.toString() || `unknown_${Date.now()}`,
          name: 'Unknown Chat',
          lastMessage: '',
          time: '',
          lastMessageDate: 0,
          unreadCount: 0,
          isGroup: false,
          isPinned: false,
          isOnline: false,
          lastMessageSender: undefined,
          avatar: { hasPhoto: false },
        };
      }
    });

    // Сортируем: сначала закрепленные, потом по времени последнего сообщения
    return dialogsData.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.lastMessageDate - a.lastMessageDate;
    });
  }

  async getMessages(sessionId, chatId, limit = 50) {
    const session = this.sessions.get(sessionId);
    let client = this.clients.get(sessionId);

    if (!session || !session.authenticated) {
      throw new Error('Session not found or not authenticated');
    }

    // Restore client if not active
    if (!client) {
      const restored = await this.restoreClient(sessionId);
      if (!restored) {
        throw new Error('Failed to restore session');
      }
      client = this.clients.get(sessionId);
    }

    // Get current user ID for better isOwn detection
    let currentUserId = null;
    try {
      const me = await client.getMe();
      currentUserId = me.id.toString();
      console.log(`Current user ID: ${currentUserId}`);
    } catch (error) {
      console.warn('Failed to get current user ID:', error);
    }

    let messages;
    try {
      messages = await client.getMessages(chatId, { limit });
    } catch (error) {
      console.error(`Failed to get messages for chat ${chatId}:`, error);

      // If entity not found, try to resolve it first
      if (error.message.includes('Could not find the input entity')) {
        console.log(`Attempting to resolve entity for chat ${chatId}`);
        try {
          // Try to get the entity first
          await client.getEntity(chatId);
          // If successful, try getting messages again
          messages = await client.getMessages(chatId, { limit });
        } catch (resolveError) {
          console.error(`Failed to resolve entity for chat ${chatId}:`, resolveError);
          return []; // Return empty array if entity cannot be resolved
        }
      } else {
        throw error; // Re-throw other errors
      }
    }

    return messages.map((message) => {
      // Better isOwn detection: use both 'out' flag and fromId comparison
      let isOwn = message.out || false;

      // Additional check: if we have currentUserId, compare with fromId
      if (currentUserId && message.fromId) {
        const messageFromId = message.fromId.toString();
        isOwn = isOwn || (messageFromId === currentUserId);
      }

      const messageData = {
        id: this.safeToString(message.id),
        telegramId: message.id,
        chatId: this.safeToString(chatId),
        fromId: this.safeToString(message.fromId),
        fromName: this.getMessageSenderName(message),
        text: message.message || '',
        date: new Date(message.date * 1000),
        editDate: message.editDate ? new Date(message.editDate * 1000) : undefined,
        isOwn: isOwn,
        isRead: !message.unread,
        isDeleted: message.deleted || false,
        isEdited: message.editDate && message.editDate !== message.date,
        views: message.views,
        replyToMsgId: message.replyTo?.replyToMsgId,
        forwardedFrom: message.fwdFrom ? {
          fromId: this.safeToString(message.fwdFrom.fromId),
          fromName: message.fwdFrom.fromName,
          date: message.fwdFrom.date ? new Date(message.fwdFrom.date * 1000) : undefined
        } : undefined,
        type: this.getMessageType(message),
        media: this.extractMediaFromMessage(message)
      };

      // Debug logging
      console.log(`Message ${message.id}: out=${message.out}, fromId=${this.safeToString(message.fromId)}, currentUserId=${currentUserId}, isOwn=${messageData.isOwn}`);

      return messageData;
    });
  }

  async getMessagesBeforeDate(sessionId, chatId, beforeDate, limit = 20) {
    console.log(`getMessagesBeforeDate called: sessionId=${sessionId}, chatId=${chatId}, beforeDate=${beforeDate}, limit=${limit}`);

    const session = this.sessions.get(sessionId);
    let client = this.clients.get(sessionId);

    if (!session || !session.authenticated) {
      throw new Error('Session not found or not authenticated');
    }

    // Restore client if not active
    if (!client) {
      console.log('Restoring client for session:', sessionId);
      const restored = await this.restoreClient(sessionId);
      if (!restored) {
        throw new Error('Failed to restore session');
      }
      client = this.clients.get(sessionId);
    }

    // Get current user ID for better isOwn detection
    let currentUserId = null;
    try {
      const me = await client.getMe();
      currentUserId = me.id.toString();
    } catch (error) {
      console.warn('Failed to get current user ID:', error);
    }

    // Сначала получим сообщения чтобы найти offsetId по дате
    console.log('First, getting recent messages to find offsetId by date...');

    let messages;
    try {
      // First, get recent messages to find a message ID that's close to our target date
      console.log('Getting recent messages to find offset point...');
      const recentMessages = await client.getMessages(chatId, { limit: 100 });
      console.log(`Got ${recentMessages.length} recent messages`);

      // Find message closest to our target date
      let offsetId = null;
      const targetTimestamp = Math.floor(beforeDate.getTime() / 1000);

      for (const msg of recentMessages) {
        if (msg.date <= targetTimestamp) {
          offsetId = msg.id;
          console.log(`Found offsetId ${offsetId} for date ${new Date(msg.date * 1000)}`);
          break;
        }
      }

      if (offsetId) {
        // Get messages before this point
        console.log(`Getting messages before ID ${offsetId}`);
        messages = await client.getMessages(chatId, {
          limit,
          offsetId: offsetId,
          addOffset: 1 // Skip the offset message itself
        });
      } else {
        console.log('No suitable offset found, getting older messages with max_id approach');
        // Fallback: use the oldest message from recent batch as starting point
        if (recentMessages.length > 0) {
          const oldestRecent = recentMessages[recentMessages.length - 1];
          messages = await client.getMessages(chatId, {
            limit,
            maxId: oldestRecent.id - 1
          });
        } else {
          messages = [];
        }
      }

      console.log(`Received ${messages.length} older messages from gramjs`);
    } catch (error) {
      console.error(`Failed to get older messages for chat ${chatId}:`, error);

      // If entity not found, try to resolve it first
      if (error.message.includes('Could not find the input entity')) {
        console.log(`Attempting to resolve entity for chat ${chatId}`);
        try {
          // Try to get the entity first
          await client.getEntity(chatId);
          // If successful, try a simple approach
          messages = await client.getMessages(chatId, { limit: limit * 2 });
          console.log(`After entity resolve, received ${messages.length} messages`);
        } catch (resolveError) {
          console.error(`Failed to resolve entity for chat ${chatId}:`, resolveError);
          return []; // Return empty array if entity cannot be resolved
        }
      } else {
        throw error; // Re-throw other errors
      }
    }

    return messages.map((message) => {
      // Better isOwn detection: use both 'out' flag and fromId comparison
      let isOwn = message.out || false;

      // Additional check: if we have currentUserId, compare with fromId
      if (currentUserId && message.fromId) {
        const messageFromId = message.fromId.toString();
        isOwn = isOwn || (messageFromId === currentUserId);
      }

      const messageData = {
        id: this.safeToString(message.id),
        telegramId: message.id,
        chatId: this.safeToString(chatId),
        fromId: this.safeToString(message.fromId),
        fromName: this.getMessageSenderName(message),
        text: message.message || '',
        date: new Date(message.date * 1000),
        editDate: message.editDate ? new Date(message.editDate * 1000) : undefined,
        isOwn: isOwn,
        isRead: !message.unread,
        isDeleted: message.deleted || false,
        isEdited: message.editDate && message.editDate !== message.date,
        views: message.views,
        replyToMsgId: message.replyTo?.replyToMsgId,
        forwardedFrom: message.fwdFrom ? {
          fromId: this.safeToString(message.fwdFrom.fromId),
          fromName: message.fwdFrom.fromName,
          date: message.fwdFrom.date ? new Date(message.fwdFrom.date * 1000) : undefined
        } : undefined,
        type: this.getMessageType(message),
        media: this.extractMediaFromMessage(message)
      };

      console.log(`Older message ${message.id}: out=${message.out}, fromId=${this.safeToString(message.fromId)}, currentUserId=${currentUserId}, isOwn=${messageData.isOwn}, date=${messageData.date}`);

      return messageData;
    });
  }

  async getMessagesBeforeId(sessionId, chatId, messageId, limit = 20) {
    console.log(`getMessagesBeforeId called: sessionId=${sessionId}, chatId=${chatId}, messageId=${messageId}, limit=${limit}`);

    const session = this.sessions.get(sessionId);
    let client = this.clients.get(sessionId);

    if (!session || !session.authenticated) {
      throw new Error('Session not found or not authenticated');
    }

    // Restore client if not active
    if (!client) {
      console.log('Restoring client for session:', sessionId);
      const restored = await this.restoreClient(sessionId);
      if (!restored) {
        throw new Error('Failed to restore session');
      }
      client = this.clients.get(sessionId);
    }

    // Get current user ID for better isOwn detection
    let currentUserId = null;
    try {
      const me = await client.getMe();
      currentUserId = me.id.toString();
    } catch (error) {
      console.warn('Failed to get current user ID:', error);
    }

    let messages;
    try {
      console.log(`Getting messages before ID ${messageId}`);
      messages = await client.getMessages(chatId, {
        limit,
        maxId: messageId - 1
      });
      console.log(`Received ${messages.length} messages before ID ${messageId}`);
    } catch (error) {
      console.error(`Failed to get messages before ID ${messageId}:`, error);

      // If entity not found, try to resolve it first
      if (error.message.includes('Could not find the input entity')) {
        console.log(`Attempting to resolve entity for chat ${chatId}`);
        try {
          await client.getEntity(chatId);
          messages = await client.getMessages(chatId, {
            limit,
            maxId: messageId - 1
          });
          console.log(`After entity resolve, received ${messages.length} messages`);
        } catch (resolveError) {
          console.error(`Failed to resolve entity for chat ${chatId}:`, resolveError);
          return [];
        }
      } else {
        throw error;
      }
    }

    return messages.map((message) => {
      // Better isOwn detection: use both 'out' flag and fromId comparison
      let isOwn = message.out || false;

      // Additional check: if we have currentUserId, compare with fromId
      if (currentUserId && message.fromId) {
        const messageFromId = this.safeToString(message.fromId);
        isOwn = isOwn || (messageFromId === currentUserId);
      }

      const messageData = {
        id: this.safeToString(message.id),
        telegramId: message.id,
        chatId: this.safeToString(chatId),
        fromId: this.safeToString(message.fromId),
        fromName: this.getMessageSenderName(message),
        text: message.message || '',
        date: new Date(message.date * 1000),
        editDate: message.editDate ? new Date(message.editDate * 1000) : undefined,
        isOwn: isOwn,
        isRead: !message.unread,
        isDeleted: message.deleted || false,
        isEdited: message.editDate && message.editDate !== message.date,
        views: message.views,
        replyToMsgId: message.replyTo?.replyToMsgId,
        forwardedFrom: message.fwdFrom ? {
          fromId: this.safeToString(message.fwdFrom.fromId),
          fromName: message.fwdFrom.fromName,
          date: message.fwdFrom.date ? new Date(message.fwdFrom.date * 1000) : undefined
        } : undefined,
        type: this.getMessageType(message),
        media: this.extractMediaFromMessage(message)
      };

      console.log(`Message before ID ${message.id}: out=${message.out}, fromId=${this.safeToString(message.fromId)}, currentUserId=${currentUserId}, isOwn=${messageData.isOwn}, date=${messageData.date}`);

      return messageData;
    });
  }

  async sendMessage(sessionId, chatId, text) {
    const session = this.sessions.get(sessionId);
    let client = this.clients.get(sessionId);

    if (!session || !session.authenticated) {
      throw new Error('Session not found or not authenticated');
    }

    // Restore client if not active
    if (!client) {
      const restored = await this.restoreClient(sessionId);
      if (!restored) {
        throw new Error('Failed to restore session');
      }
      client = this.clients.get(sessionId);
    }

    await client.sendMessage(chatId, { message: text });
    console.log(`Message sent to ${chatId}: ${text}`);
  }

  // Message processing helper methods
  safeToString(id) {
    if (!id) return undefined;
    if (typeof id === 'string') return id;
    if (typeof id === 'number') return id.toString();
    if (typeof id === 'object' && id.toString) return id.toString();
    return String(id);
  }

  getMessageType(message) {
    if (message.media) {
      const media = message.media;

      if (media.className === 'MessageMediaPhoto') {
        return 'photo';
      } else if (media.className === 'MessageMediaDocument') {
        const document = media.document;
        if (document && document.attributes) {
          for (const attr of document.attributes) {
            if (attr.className === 'DocumentAttributeVideo') {
              return attr.roundMessage ? 'video_note' : 'video';
            } else if (attr.className === 'DocumentAttributeAudio') {
              return attr.voice ? 'voice' : 'audio';
            } else if (attr.className === 'DocumentAttributeSticker') {
              return 'sticker';
            } else if (attr.className === 'DocumentAttributeAnimated') {
              return 'video'; // GIF
            }
          }
        }
        return 'document';
      } else if (media.className === 'MessageMediaContact') {
        return 'contact';
      } else if (media.className === 'MessageMediaGeo' || media.className === 'MessageMediaVenue') {
        return 'location';
      } else if (media.className === 'MessageMediaPoll') {
        return 'poll';
      } else if (media.className === 'MessageMediaWebPage') {
        return 'webpage';
      } else if (media.className === 'MessageMediaGame') {
        return 'game';
      } else if (media.className === 'MessageMediaInvoice') {
        return 'invoice';
      }
    }

    return message.message ? 'text' : 'unknown';
  }

  extractMediaFromMessage(message) {
    if (!message.media) return [];

    const media = message.media;
    const mediaFiles = [];

    if (media.className === 'MessageMediaPhoto') {
      const photo = media.photo;
      if (photo && photo.sizes) {
        // Находим самое большое фото
        const largestSize = photo.sizes.reduce((prev, current) => {
          if (current.className === 'PhotoSize' && prev.className === 'PhotoSize') {
            return (current.w * current.h) > (prev.w * prev.h) ? current : prev;
          }
          return current.className === 'PhotoSize' ? current : prev;
        });

        mediaFiles.push({
          id: `photo_${photo.id}_${Date.now()}`,
          type: 'photo',
          fileId: photo.id.toString(),
          accessHash: photo.accessHash.toString(),
          size: largestSize.size || 0,
          width: largestSize.w,
          height: largestSize.h,
          dcId: photo.dcId
        });
      }
    } else if (media.className === 'MessageMediaDocument') {
      const document = media.document;
      if (document) {
        const mediaFile = {
          id: `doc_${document.id}_${Date.now()}`,
          type: 'document',
          fileId: document.id.toString(),
          accessHash: document.accessHash.toString(),
          size: document.size,
          filename: this.getDocumentFilename(document),
          mimeType: document.mimeType,
          dcId: document.dcId
        };

        // Определяем тип документа по атрибутам
        if (document.attributes) {
          for (const attr of document.attributes) {
            if (attr.className === 'DocumentAttributeVideo') {
              mediaFile.type = attr.roundMessage ? 'video_note' : 'video';
              mediaFile.width = attr.w;
              mediaFile.height = attr.h;
              mediaFile.duration = attr.duration;
            } else if (attr.className === 'DocumentAttributeAudio') {
              mediaFile.type = attr.voice ? 'voice' : 'audio';
              mediaFile.duration = attr.duration;
              mediaFile.performer = attr.performer;
              mediaFile.title = attr.title;
            } else if (attr.className === 'DocumentAttributeSticker') {
              mediaFile.type = 'sticker';
              mediaFile.alt = attr.alt;
            }
          }
        }

        // Извлекаем пре��ью если есть
        if (document.thumbs && document.thumbs.length > 0) {
          const thumb = document.thumbs[0];
          if (thumb.className === 'PhotoSize') {
            mediaFile.thumbnail = {
              width: thumb.w,
              height: thumb.h,
              size: thumb.size
            };
          }
        }

        mediaFiles.push(mediaFile);
      }
    } else if (media.className === 'MessageMediaContact') {
      mediaFiles.push({
        id: `contact_${Date.now()}`,
        type: 'contact',
        phoneNumber: media.phoneNumber,
        firstName: media.firstName,
        lastName: media.lastName,
        userId: media.userId?.toString()
      });
    } else if (media.className === 'MessageMediaGeo') {
      mediaFiles.push({
        id: `location_${Date.now()}`,
        type: 'location',
        latitude: media.geo.lat,
        longitude: media.geo.long
      });
    } else if (media.className === 'MessageMediaVenue') {
      mediaFiles.push({
        id: `venue_${Date.now()}`,
        type: 'location',
        latitude: media.geo.lat,
        longitude: media.geo.long,
        title: media.title,
        address: media.address,
        provider: media.provider,
        venueId: media.venueId
      });
    } else if (media.className === 'MessageMediaPoll') {
      mediaFiles.push({
        id: `poll_${Date.now()}`,
        type: 'poll',
        question: media.poll.question,
        answers: media.poll.answers.map(answer => ({
          text: answer.text,
          option: answer.option
        })),
        closed: media.poll.closed,
        multipleChoice: media.poll.multipleChoice
      });
    }

    return mediaFiles;
  }

  getDocumentFilename(document) {
    if (document.attributes) {
      for (const attr of document.attributes) {
        if (attr.className === 'DocumentAttributeFilename') {
          return attr.fileName;
        }
      }
    }
    return `document_${document.id}`;
  }

  getMessageSenderName(message) {
    // Эт�� упрощенная версия, в реальности нужно будет получать информацию о пользователе
    if (message.fromId) {
      // Здесь ��ожно добавить кэш пользователей и получать их имена
      return `User ${message.fromId}`;
    }
    return null;
  }

  // Helper methods
  getEntityName(entity) {
    if (entity.firstName && entity.lastName) {
      return `${entity.firstName} ${entity.lastName}`;
    }
    if (entity.firstName) {
      return entity.firstName;
    }
    if (entity.title) {
      return entity.title;
    }
    if (entity.username) {
      return entity.username;
    }
    // Fallback for deleted accounts or channels without names
    return entity.id ? `User ${entity.id}` : 'Unknown';
  }

  isGroup(entity) {
    return entity.className === 'Chat' || entity.className === 'Channel';
  }

  isOnline(entity) {
    if (entity.status) {
      return entity.status.className === 'UserStatusOnline';
    }
    return false;
  }

  getLastMessageSender(message, entity) {
    if (this.isGroup(entity) && message && message.fromId) {
      return 'User';
    }
    return undefined;
  }

  getEntityAvatar(entity) {
    // Возвращаем данные для аватарки
    const avatarData = {
      hasPhoto: entity.photo ? true : false,
      photoId: entity.photo?.photoId?.toString(),
      firstName: entity.firstName,
      lastName: entity.lastName,
      title: entity.title,
      username: entity.username
    };

    console.log(`Avatar for ${entity.firstName || entity.title}:`, avatarData);
    return avatarData;
  }

  formatMessageTime(date) {
    if (!date) return '';
    
    const messageDate = new Date(date * 1000);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);

    if (messageDate >= today) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (messageDate >= yesterday) {
      return 'Yesterday';
    } else {
      return messageDate.toLocaleDateString();
    }
  }

  async logout(sessionId) {
    const session = this.sessions.get(sessionId);
    const client = this.clients.get(sessionId);

    if (session && client) {
      try {
        const { Api } = this.telegramModules;
        await client.invoke(new Api.auth.LogOut());
        await client.disconnect();
        console.log(`Logout completed for session ${sessionId}`);
      } catch (error) {
        console.error('Error during logout:', error);
      }
      this.clients.delete(sessionId);
    }

    this.sessions.delete(sessionId);
    this.deleteSessionFile(sessionId); // Delete saved session file
    console.log(`Session ${sessionId} cleaned up`);
  }

  async downloadMedia(sessionId, messageId, mediaIndex = 0) {
    const session = this.sessions.get(sessionId);
    const client = this.clients.get(sessionId);

    if (!session || !session.authenticated || !client) {
      throw new Error('Session not found or not authenticated');
    }

    try {
      // Получаем сообщение
      const messages = await client.getMessages(session.phone, {
        ids: [parseInt(messageId)]
      });

      const message = messages[0];
      if (!message || !message.media) {
        throw new Error('Message or media not found');
      }

      // Загружаем медиафайл
      const buffer = await client.downloadMedia(message, {
        progressCallback: (progress) => {
          console.log(`Download progress: ${progress}%`);
        }
      });

      return {
        buffer: buffer,
        filename: this.getMediaFilename(message.media),
        mimeType: this.getMediaMimeType(message.media)
      };
    } catch (error) {
      console.error('Failed to download media:', error);
      throw new Error(`Failed to download media: ${error.message}`);
    }
  }

  getMediaFilename(media) {
    if (media.className === 'MessageMediaPhoto') {
      return `photo_${Date.now()}.jpg`;
    } else if (media.className === 'MessageMediaDocument') {
      const document = media.document;
      if (document.attributes) {
        for (const attr of document.attributes) {
          if (attr.className === 'DocumentAttributeFilename') {
            return attr.fileName;
          }
        }
      }
      return `document_${document.id}`;
    }
    return `media_${Date.now()}`;
  }

  getMediaMimeType(media) {
    if (media.className === 'MessageMediaPhoto') {
      return 'image/jpeg';
    } else if (media.className === 'MessageMediaDocument') {
      return media.document.mimeType || 'application/octet-stream';
    }
    return 'application/octet-stream';
  }

  async downloadAvatar(sessionId, photoId) {
    const session = this.sessions.get(sessionId);
    const client = this.clients.get(sessionId);

    if (!session || !session.authenticated || !client) {
      throw new Error('Session not found or not authenticated');
    }

    try {
      // Пока возвращаем null - реализация загрузки аватаров сложная в gramjs
      // В реальном приложении здесь будет код для загрузки через client.downloadProfilePhoto()
      return null;
    } catch (error) {
      console.error('Failed to download avatar:', error);
      return null;
    }
  }

  async disconnect(sessionId) {
    await this.logout(sessionId);
  }

  ensureSessionsDir() {
    try {
      if (!fs.existsSync(this.sessionsDir)) {
        fs.mkdirSync(this.sessionsDir, { recursive: true });
        console.log('Created sessions directory:', this.sessionsDir);
      }
    } catch (error) {
      console.warn('Failed to create sessions directory:', error);
    }
  }

  saveSessionToFile(sessionId, sessionString) {
    try {
      const sessionFile = path.join(this.sessionsDir, `${sessionId}.json`);
      const sessionData = {
        sessionId,
        sessionString,
        timestamp: Date.now()
      };
      fs.writeFileSync(sessionFile, JSON.stringify(sessionData, null, 2));
      console.log(`Session saved to file: ${sessionFile}`);
    } catch (error) {
      console.error('Failed to save session to file:', error);
    }
  }

  loadSessionFromFile(sessionId) {
    try {
      const sessionFile = path.join(this.sessionsDir, `${sessionId}.json`);
      if (fs.existsSync(sessionFile)) {
        const sessionData = JSON.parse(fs.readFileSync(sessionFile, 'utf8'));
        console.log(`Session loaded from file: ${sessionFile}`);
        return sessionData.sessionString;
      }
    } catch (error) {
      console.error(`Failed to load session from file: ${error}`);
    }
    return null;
  }

  deleteSessionFile(sessionId) {
    try {
      const sessionFile = path.join(this.sessionsDir, `${sessionId}.json`);
      if (fs.existsSync(sessionFile)) {
        fs.unlinkSync(sessionFile);
        console.log(`Session file deleted: ${sessionFile}`);
      }
    } catch (error) {
      console.error('Failed to delete session file:', error);
    }
  }

  async loadSavedSessions() {
    try {
      if (!fs.existsSync(this.sessionsDir)) {
        return;
      }

      const sessionFiles = fs.readdirSync(this.sessionsDir).filter(file => file.endsWith('.json'));
      console.log(`Found ${sessionFiles.length} saved sessions`);

      for (const file of sessionFiles) {
        try {
          const sessionData = JSON.parse(fs.readFileSync(path.join(this.sessionsDir, file), 'utf8'));
          const { sessionId, sessionString } = sessionData;

          // Extract phone from sessionId (format: session_phone)
          const phone = sessionId.replace('session_', '').replace(/[^0-9]/g, '');
          if (phone) {
            // Restore session without connecting (will connect on demand)
            this.sessions.set(sessionId, {
              phone: `+${phone}`,
              authenticated: true,
              sessionString: sessionString
            });
            console.log(`Restored session for phone: +${phone}`);
          }
        } catch (error) {
          console.error(`Failed to restore session from ${file}:`, error);
        }
      }
    } catch (error) {
      console.error('Failed to load saved sessions:', error);
    }
  }

  async restoreClient(sessionId) {
    const session = this.sessions.get(sessionId);
    if (!session || !session.sessionString) {
      return false;
    }

    try {
      console.log(`Restoring client for session: ${sessionId}`);
      await this.createClient(session.phone, session.sessionString);
      return true;
    } catch (error) {
      console.error(`Failed to restore client for session ${sessionId}:`, error);
      // Remove invalid session
      this.sessions.delete(sessionId);
      this.deleteSessionFile(sessionId);
      return false;
    }
  }
}

export const telegramServerService = new TelegramServerService();
